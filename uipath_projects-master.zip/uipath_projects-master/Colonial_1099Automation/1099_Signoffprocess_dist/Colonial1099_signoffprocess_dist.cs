﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using System.Net.Mail;
using System.IO.Compression;
using outlook = Microsoft.Office.Interop.Outlook;
using System.Net;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;

namespace _1099_Signoffprocess_dist
{
    class Colonial1099_signoffprocess_dist
    {/// <summary>
     /// Get the text files and convert them to excel.Filter according to the type and calculate the box values,Copy the calculated values from the excel to sign off excel then format it and save to the destination folder.
     /// Attach the output files and send mail.Move input and output files to archieve path.
     /// </summary>
        static void Main(string[] args)
        {
            string inputFile_path = ConfigurationManager.AppSettings["inputfile_path"].ToString();
            string inputArchive_path = ConfigurationManager.AppSettings["inputarchive_path"].ToString();
            string outputArchive_path = ConfigurationManager.AppSettings["outputarchive_path"].ToString();
            string dstnpath_CLA_POS_POS_Combined = ConfigurationManager.AppSettings["dstnpath_CLA_POS_POS_Combined"].ToString();
            string source_CLA_POS = ConfigurationManager.AppSettings["source_CLA_POS"].ToString();
            string template_CLA_POS = ConfigurationManager.AppSettings["template_CLA_POS"].ToString();
            string destination_CLA_POS = dstnpath_CLA_POS_POS_Combined + "CLA_POS_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string signoff_template_CLA_POS = ConfigurationManager.AppSettings["signoff_template_CLA_POS"].ToString();
            string destsignoff_CLA_POS = dstnpath_CLA_POS_POS_Combined + "Sign Off for Year End " + DateTime.Now.ToString("yyyy") + "Tax Files - CLA_POS" + ".xlsx";


            string source_POS_Combined = ConfigurationManager.AppSettings["source_POS_Combined"].ToString();
            string template_POS_Combined = ConfigurationManager.AppSettings["template_POS_Combined"].ToString();
            string destination_POS_Combined = dstnpath_CLA_POS_POS_Combined + "POS_Combined_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string signoff_template_POS_Combined = ConfigurationManager.AppSettings["signoff_template_POS_Combined"].ToString();
            string destsignoff_POS_Combined = dstnpath_CLA_POS_POS_Combined + "Sign Off for Year End " + DateTime.Now.ToString("yyyy") + "Tax Files - POS_Combined" + ".xlsx";

            string dstnpath_CLA_CLM_Combined_CLM_Combined = ConfigurationManager.AppSettings["dstnpath_CLA_CLM_Combined_CLM_Combined"].ToString();
            string source_CLM_Combined = ConfigurationManager.AppSettings["source_CLM_Combined"].ToString();
            string template_CLM_Combined = ConfigurationManager.AppSettings["template_CLM_Combined"].ToString();
            string destination_CLM_Combined = dstnpath_CLA_CLM_Combined_CLM_Combined + "CLM_Combined_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string signoff_template_CLM_Combined = ConfigurationManager.AppSettings["signoff_template_CLM_Combined"].ToString();
            string destsignoff_CLM_Combined = dstnpath_CLA_CLM_Combined_CLM_Combined + "Sign Off for Year End " + DateTime.Now.ToString("yyyy") + "Tax Files - CLM_Combined" + ".xlsx";

            string source_CLA_CLM_Combined = ConfigurationManager.AppSettings["source_CLA_CLM_Combined"].ToString();
            string template_CLA_CLM_Combined = ConfigurationManager.AppSettings["template_CLA_CLM_Combined"].ToString();
            string destination_CLA_CLM_Combined = dstnpath_CLA_CLM_Combined_CLM_Combined + "CLA_CLM_Combined_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string signoff_template_CLA_CLM_Combined = ConfigurationManager.AppSettings["signoff_template_CLA_CLM_Combined"].ToString();
            string destsignoff_CLA_CLM_Combined = dstnpath_CLA_CLM_Combined_CLM_Combined + "Sign Off for Year End " + DateTime.Now.ToString("yyyy") + "Tax Files - CLA_CLM_Combined" + ".xlsx";

            string dstnpath_CLA_POS_1035_1099R_POS_1035_1099R = ConfigurationManager.AppSettings["dstnpath_CLA_POS_1035_1099R_POS_1035_1099R"].ToString();
            string source_CLA_POS_1035_1099R = ConfigurationManager.AppSettings["source_CLA_POS_1035_1099R"].ToString();
            string template_CLA_POS_1035_1099R = ConfigurationManager.AppSettings["template_CLA_POS_1035_1099R"].ToString();
            string destination_CLA_POS_1035_1099R = dstnpath_CLA_POS_1035_1099R_POS_1035_1099R + "CLA_POS_1035_1099R_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string signoff_template_CLA_POS_1035_1099R = ConfigurationManager.AppSettings["signoff_template_CLA_POS_1035_1099R"].ToString();
            string destsignoff_CLA_POS_1035_1099R = dstnpath_CLA_POS_1035_1099R_POS_1035_1099R + "Sign Off for Year End " + DateTime.Now.ToString("yyyy") + "Tax Files - CLA_POS_1035_1099R" + ".xlsx";

            string source_POS_1035_1099R = ConfigurationManager.AppSettings["source_POS_1035_1099R"].ToString();
            string template_POS_1035_1099R = ConfigurationManager.AppSettings["template_POS_1035_1099R"].ToString();
            string destination_POS_1035_1099R = dstnpath_CLA_POS_1035_1099R_POS_1035_1099R + "POS_1035_1099R_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string signoff_template_POS_1035_1099R = ConfigurationManager.AppSettings["signoff_template_POS_1035_1099R"].ToString();
            string destsignoff_POS_1035_1099R = dstnpath_CLA_POS_1035_1099R_POS_1035_1099R + "Sign Off for Year End " + DateTime.Now.ToString("yyyy") + "Tax Files - POS_1035_1099R" + ".xlsx";

            string htmlFile = ConfigurationManager.AppSettings["HTMLfile"].ToString();
            string mail_From = ConfigurationManager.AppSettings["Mail_From"].ToString();
            string mail_CC = ConfigurationManager.AppSettings["Mail_CC"].ToString();
            string mailTo_CLM_Combined = ConfigurationManager.AppSettings["CLM_Combined_To"].ToString();
            string mailTo_POS_Combined = ConfigurationManager.AppSettings["POS_Combined_To"].ToString();
            string mailTo_POS_1035_1099R = ConfigurationManager.AppSettings["POS_1035_1099R_To"].ToString();
            string logPath = ConfigurationManager.AppSettings["Logs"].ToString();
            string logFilename = logPath + "Logs -" + DateTime.Now.ToString("yyyyMMdd") + ".txt";

            string zipFilepath = ConfigurationManager.AppSettings["zipfilepath"].ToString();
            string zipfile_CLA_POS_POS_Combined = zipFilepath + "CLA_POS and POS_Combined files" + DateTime.Now.ToString("yyyy") + ".zip";
            string zipfile_CLA_CLM_Combined_CLM_Combined = zipFilepath + "CLA_CLM_Combined and CLM_Combined files " + DateTime.Now.ToString("yyyy") + ".zip";
            string zipfile_CLA_POS_1035_1099R_POS_1035_1099R = zipFilepath + "CLA_POS_1035_1099R and POS_1035_1099R files " + DateTime.Now.ToString("yyyy") + ".zip";


            excel.Application excellApp = new excel.Application();
            object misValue = System.Reflection.Missing.Value;
            //excellApp.Visible = true;

            CLA_POS(source_CLA_POS, template_CLA_POS, signoff_template_CLA_POS, destination_CLA_POS, destsignoff_CLA_POS, misValue, excellApp, logFilename);

            CLM_Combined(source_CLM_Combined, template_CLM_Combined, signoff_template_CLM_Combined, destination_CLM_Combined,
                            destsignoff_CLM_Combined, misValue, excellApp, logFilename);

            POS_Combined(source_POS_Combined, template_POS_Combined, signoff_template_POS_Combined, destination_POS_Combined,
                                 destsignoff_POS_Combined, misValue, excellApp, logFilename);

            CLA_POS_1035_1099R(source_CLA_POS_1035_1099R, template_CLA_POS_1035_1099R, signoff_template_CLA_POS_1035_1099R,
                                     destination_CLA_POS_1035_1099R, destsignoff_CLA_POS_1035_1099R, misValue, excellApp, logFilename);

            POS_1035_1099R(source_POS_1035_1099R, template_POS_1035_1099R, signoff_template_POS_1035_1099R,
                                     destination_POS_1035_1099R, destsignoff_POS_1035_1099R, misValue, excellApp, logFilename);

            CLA_CLM_Combined(source_CLA_CLM_Combined, template_CLA_CLM_Combined, signoff_template_CLA_CLM_Combined,
                                          destination_CLA_CLM_Combined, destsignoff_CLA_CLM_Combined, misValue, excellApp, logFilename);


            sendmail(mail_From, dstnpath_CLA_CLM_Combined_CLM_Combined, mailTo_CLM_Combined, mail_CC, dstnpath_CLA_POS_1035_1099R_POS_1035_1099R,
                         mailTo_POS_1035_1099R, dstnpath_CLA_POS_POS_Combined, mailTo_POS_Combined, htmlFile, logFilename,
                         zipfile_CLA_CLM_Combined_CLM_Combined, zipfile_CLA_POS_POS_Combined, zipfile_CLA_POS_1035_1099R_POS_1035_1099R);

            MoveInput_OutputfilesToArchive(inputFile_path, inputArchive_path, dstnpath_CLA_CLM_Combined_CLM_Combined,
            dstnpath_CLA_POS_1035_1099R_POS_1035_1099R, dstnpath_CLA_POS_POS_Combined, outputArchive_path, logFilename);

            excellApp.Quit();


        }

        /// <summary>
        /// Extract data from CLA_POS files and paste it into the excel template.Filter according to the form type,Calculate the box values and save the template to the destination folder.
        /// Open Signoff template and copy the calculated box values from the excel template to the Signofftemplate sheet and save it to the destination folder.
        /// </summary>
        /// <param name="source">Path of the source file.</param>
        /// <param name="template">Path of the excel template.</param>
        /// <param name="signoffTemplate">Path of the signoff excel template.</param>
        /// <param name="destination">Path of the destination file name.</param>
        /// <param name="signoffDestination">Path of the signoff Destination filename.</param>
        /// <param name="misValue">Name of the excel object.</param>
        /// <param name="excellApp">Name of the excel application.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void CLA_POS(string source, string template, string signoffTemplate, string destination, string signoffDestination, object misValue, excel.Application excellApp, string logFilename)

        {
            try
            {
                excellApp.Workbooks.OpenText(source, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                          misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);
                var wb_Text = excellApp.ActiveWorkbook;
                var ws_Text = (excel.Worksheet)wb_Text.Worksheets.Item[1];

                ws_Text.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                var wb_CLA_POS = excellApp.Workbooks.Add(template);
                excel.Sheets excelSheets = wb_CLA_POS.Worksheets;
                excel.Worksheet ws_Sheet1 = (excel.Worksheet)excelSheets.get_Item("Sheet1");
                ws_Sheet1.get_Range("A2").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text.get_Range("A1").Copy();
                wb_Text.Close(SaveChanges: false);

                var lastUsedRow_sheet1 = ws_Sheet1.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                       excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                var usedRow = lastUsedRow_sheet1;
                //added formula sheeet to correct the zipcode format
                excel.Worksheet ws_Formula = (excel.Worksheet)excelSheets.get_Item("formula");
                ws_Formula.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from = ws_Formula.get_Range("A1:A" + usedRow);
                excel.Range to = ws_Sheet1.get_Range("O1:O" + usedRow);
                from.Copy(to);
                //copy the state from n column to AB column
                excel.Range from_st = ws_Sheet1.get_Range("N2:N" + usedRow);
                excel.Range to_st = ws_Sheet1.get_Range("AB2:AB" + usedRow);
                from_st.Copy(to_st);
                ws_Sheet1.AutoFilterMode = false;
                ws_Sheet1.Columns.AutoFilter(1, "=9");
                excel.Worksheet ws_1099R = (excel.Worksheet)excelSheets.get_Item("1099R");
                ws_Sheet1.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_1099R.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                var lastUsedRow_1099R = ws_1099R.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                  excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                var totalrows_1099R = lastUsedRow_1099R - 1;

                ws_Sheet1.Columns.AutoFilter(1, "=6");
                excel.Worksheet ws_1099INT = (excel.Worksheet)excelSheets.get_Item("1099INT");
                ws_Sheet1.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_1099INT.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                var lastUsedRow_1099INT = ws_1099INT.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                 excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                var totalrows_1099INT = lastUsedRow_1099INT - 1;

                ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, 44] = "Total_1099R";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, 44] = "Total_1099INT";
                int j = 45;
                for (char Outer = 'A'; Outer <= 'B'; Outer++)
                {
                    for (char Inner = 'S'; Inner <= 'Z'; Inner++)
                    {
                        if (Outer == 'B' && Inner == 'T')
                            break;
                        if (Outer == 'B')
                            for (char Inner1 = 'A'; Inner1 <= 'O'; Inner1++)
                            {

                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, j] = "=SUM(1099R!" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + lastUsedRow_1099R + ")";

                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(1099INT!" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + lastUsedRow_1099INT + ")";

                                if (Inner1 == 'O')
                                    break;
                                else
                                    j++;
                            }
                        else
                            ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, j] = "=SUM(1099R!" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + lastUsedRow_1099R + ")";

                        ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(1099INT!" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + lastUsedRow_1099INT + ")";


                        j++;
                    }
                }
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 4, 43] = "Total rows_1099R";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 4, 44] = totalrows_1099R;
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 43] = "Total rows_1099INT";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 44] = totalrows_1099INT;
                ws_Sheet1.AutoFilterMode = false;
                var range = "AS" + (usedRow + 2) + ":BO" + (usedRow + 3);

                ws_Sheet1.Columns["A:BO"].AutoFit();
                ws_Sheet1.get_Range(range).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Sheet1.get_Range("AS" + (usedRow + 2)).PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                ws_1099INT.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                ws_1099R.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                ws_Formula.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_CLA_POS.SaveAs(destination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                  excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                var wb_Signoff = excellApp.Workbooks.Add(signoffTemplate);
                var ws_Signoff = (excel.Worksheet)wb_Signoff.Worksheets.Item[1];

                ws_Sheet1.get_Range("AR" + (usedRow + 4) + ":AR" + (usedRow + 4)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Sheet1.get_Range("AR" + (usedRow + 5) + ":AR" + (usedRow + 5)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Signoff.Cells[15, 2] = totalrows_1099R + totalrows_1099INT;

                ws_Sheet1.get_Range("AS" + (usedRow + 2) + ":BB" + (usedRow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BD" + (usedRow + 2) + ":BE" + (usedRow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BG" + (usedRow + 2) + ":BG" + (usedRow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BI" + (usedRow + 2) + ":BJ" + (usedRow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BL" + (usedRow + 2) + ":BN" + (usedRow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Sheet1.get_Range("AS" + (usedRow + 3) + ":BB" + (usedRow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BD" + (usedRow + 3) + ":BE" + (usedRow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BG" + (usedRow + 3) + ":BG" + (usedRow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BI" + (usedRow + 3) + ":BJ" + (usedRow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BL" + (usedRow + 3) + ":BN" + (usedRow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                wb_Signoff.SaveAs(signoffDestination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                 excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_CLA_POS.Close();
                wb_Signoff.Close();
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// Extract data from CLM_Combined files and paste it into the excel template.Filter according to the form type,Calculate the box values and save the template to the destination folder.
        /// Open Signoff template and copy the calculated box values from the excel template to the Signofftemplate sheet and save it to the destination folder.
        /// </summary>
        /// <param name="source">Path of the source file.</param>
        /// <param name="template">Path of the excel template.</param>
        /// <param name="signoffTemplate">Path of the signoff excel template.</param>
        /// <param name="destination">Path of the destination file name.</param>
        /// <param name="signoffDestination">Path of the signoff Destination filename.</param>
        /// <param name="misValue">Name of the excel object.</param>
        /// <param name="excellApp">Name of the excel application.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void CLM_Combined(string source, string template, string signofftemplate, string destination, string signoffDestination, object misValue, excel.Application excellApp, string logFilename)

        {
            try
            {
                excellApp.Workbooks.OpenText(source, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                   misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);
                var wb_Text = excellApp.ActiveWorkbook;
                var ws_Text = (excel.Worksheet)wb_Text.Worksheets.Item[1];

                ws_Text.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                var wb_CLM_Combined = excellApp.Workbooks.Add(template);
                excel.Sheets excelSheets = wb_CLM_Combined.Worksheets;
                excel.Worksheet ws_Sheet1 = (excel.Worksheet)excelSheets.get_Item("Sheet1");
                ws_Sheet1.get_Range("A2").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text.get_Range("A1").Copy();
                wb_Text.Close(SaveChanges: false);

                var lastUsedRow_sheet1 = ws_Sheet1.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                       excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                var usedrow = lastUsedRow_sheet1;
                excel.Worksheet ws_Formula = (excel.Worksheet)excelSheets.get_Item("formula");
                ws_Formula.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from = ws_Formula.get_Range("A1:A" + usedrow);
                excel.Range to = ws_Sheet1.get_Range("O1:O" + usedrow);
                from.Copy(to);
                //copy the state from n column to AB column
                excel.Range from_st = ws_Sheet1.get_Range("N2:N" + usedrow);
                excel.Range to_st = ws_Sheet1.get_Range("AB2:AB" + usedrow);
                from_st.Copy(to_st);
                ws_Sheet1.AutoFilterMode = false;
                ws_Sheet1.Columns.AutoFilter(1, "=A");
                excel.Worksheet ws_1099MISC = (excel.Worksheet)excelSheets.get_Item("1099MISC");
                ws_Sheet1.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_1099MISC.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                var lastUsedRow_1099MISC = ws_1099MISC.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                  excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                var totalrows_1099MISC = lastUsedRow_1099MISC - 1;

                ws_Sheet1.Columns.AutoFilter(1, "=6");
                excel.Worksheet ws_1099INT = (excel.Worksheet)excelSheets.get_Item("1099INT");
                ws_Sheet1.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_1099INT.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                var lastUsedRow_1099INT = ws_1099INT.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                 excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                var totalrows_1099INT = lastUsedRow_1099INT - 1;

                ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, 44] = "Total_1099MISC";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, 44] = "Total_1099INT";
                int j = 45;
                for (char Outer = 'A'; Outer <= 'B'; Outer++)
                {
                    for (char Inner = 'S'; Inner <= 'Z'; Inner++)
                    {
                        if (Outer == 'B' && Inner == 'T')
                            break;
                        if (Outer == 'B')
                            for (char Inner1 = 'A'; Inner1 <= 'O'; Inner1++)
                            {

                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, j] = "=SUM(1099MISC!" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + lastUsedRow_1099MISC + ")";

                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(1099INT!" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + lastUsedRow_1099INT + ")";

                                if (Inner1 == 'O')
                                    break;
                                else
                                    j++;
                            }
                        else
                            ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, j] = "=SUM(1099MISC!" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + lastUsedRow_1099MISC + ")";

                        ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(1099INT!" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + lastUsedRow_1099INT + ")";


                        j++;
                    }
                }
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 4, 43] = "Total rows_1099MISC";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 4, 44] = totalrows_1099MISC;
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 43] = "Total rows_1099INT";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 44] = totalrows_1099INT;
                ws_Sheet1.AutoFilterMode = false;
                var range = "AS" + (usedrow + 2) + ":BO" + (usedrow + 3);

                ws_Sheet1.Columns["A:BO"].AutoFit();
                ws_Sheet1.get_Range(range).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Sheet1.get_Range("AS" + (usedrow + 2)).PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_1099INT.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                ws_1099MISC.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                ws_Formula.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_CLM_Combined.SaveAs(destination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                  excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                var wb_Signoff = excellApp.Workbooks.Add(signofftemplate);
                var ws_Signoff = (excel.Worksheet)wb_Signoff.Worksheets.Item[1];

                ws_Sheet1.get_Range("AR" + (usedrow + 4) + ":AR" + (usedrow + 4)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Sheet1.get_Range("AR" + (usedrow + 5) + ":AR" + (usedrow + 5)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Signoff.Cells[15, 2] = totalrows_1099MISC + totalrows_1099INT;

                ws_Sheet1.get_Range("AS" + (usedrow + 2) + ":BB" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BD" + (usedrow + 2) + ":BE" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BG" + (usedrow + 2) + ":BG" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BI" + (usedrow + 2) + ":BJ" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BL" + (usedrow + 2) + ":BN" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Sheet1.get_Range("AS" + (usedrow + 3) + ":BB" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BD" + (usedrow + 3) + ":BE" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BG" + (usedrow + 3) + ":BG" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BI" + (usedrow + 3) + ":BJ" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BL" + (usedrow + 3) + ":BN" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                wb_Signoff.SaveAs(signoffDestination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                 excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_CLM_Combined.Close();
                wb_Signoff.Close();
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// Extract data from CLA_CLM_Combined files and paste it into the excel template.Filter according to the form type,Calculate the box values and save the template to the destination folder.
        /// Open Signoff template and copy the calculated box values from the excel template to the Signofftemplate sheet and save it to the destination folder.
        /// </summary>
        /// <param name="source">Path of the source file.</param>
        /// <param name="template">Path of the excel template.</param>
        /// <param name="signoffTemplate">Path of the signoff excel template.</param>
        /// <param name="destination">Path of the destination file name.</param>
        /// <param name="signoffDestination">Path of the signoff Destination filename.</param>
        /// <param name="misValue">Name of the excel object.</param>
        /// <param name="excellApp">Name of the excel application.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void CLA_CLM_Combined(string source, string template, string signofftemplate, string destination, string signoffDestination, object misValue, excel.Application excellApp, string logFilename)

        {
            try
            {

                excellApp.Workbooks.OpenText(source, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                   misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);
                var wb_Text = excellApp.ActiveWorkbook;
                var ws_Text = (excel.Worksheet)wb_Text.Worksheets.Item[1];


                ws_Text.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                var wb_CLA_CLM_Combined = excellApp.Workbooks.Add(template);
                excel.Sheets excelSheets = wb_CLA_CLM_Combined.Worksheets;
                excel.Worksheet ws_Sheet1 = (excel.Worksheet)excelSheets.get_Item("Sheet1");
                ws_Sheet1.get_Range("A2").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                ws_Text.get_Range("A1").Copy();
                wb_Text.Close(SaveChanges: false);

                ws_Sheet1.UsedRange.Sort(ws_Sheet1.UsedRange.Columns[1], excel.XlSortOrder.xlDescending);
                var lastUsedRow_sheet1 = ws_Sheet1.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                       excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                var usedrow = lastUsedRow_sheet1;
                excel.Worksheet ws_Formula = (excel.Worksheet)excelSheets.get_Item("formula");
                ws_Formula.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from = ws_Formula.get_Range("A1:A" + usedrow);
                excel.Range to = ws_Sheet1.get_Range("O1:O" + usedrow);
                from.Copy(to);
                //copy the state from n column to AB column
                excel.Range from_st = ws_Sheet1.get_Range("N2:N" + usedrow);
                excel.Range to_st = ws_Sheet1.get_Range("AB2:AB" + usedrow);
                from_st.Copy(to_st);


                ws_Sheet1.AutoFilterMode = false;
                ws_Sheet1.Columns.AutoFilter(1, "=A");
                excel.Worksheet ws_1099MISC = (excel.Worksheet)excelSheets.get_Item("1099MISC");
                ws_Sheet1.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_1099MISC.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                var lastUsedRow_1099MISC = ws_1099MISC.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                  excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                var totalrows_1099MISC = lastUsedRow_1099MISC - 1;

                ws_Sheet1.Columns.AutoFilter(1, "=6");
                excel.Worksheet ws_1099INT = (excel.Worksheet)excelSheets.get_Item("1099INT");
                ws_Sheet1.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_1099INT.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                var lastUsedRow_1099INT = ws_1099INT.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                 excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                var totalrows_1099INT = lastUsedRow_1099INT - 1;

                ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, 44] = "Total_1099MISC";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, 44] = "Total_1099INT";
                int j = 45;
                for (char Outer = 'A'; Outer <= 'B'; Outer++)
                {
                    for (char Inner = 'S'; Inner <= 'Z'; Inner++)
                    {
                        if (Outer == 'B' && Inner == 'T')
                            break;
                        if (Outer == 'B')
                            for (char Inner1 = 'A'; Inner1 <= 'O'; Inner1++)
                            {

                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, j] = "=SUM(1099MISC!" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + lastUsedRow_1099MISC + ")";

                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(1099INT!" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + lastUsedRow_1099INT + ")";

                                if (Inner1 == 'O')
                                    break;
                                else
                                    j++;
                            }
                        else
                            ws_Sheet1.Cells[lastUsedRow_sheet1 + 2, j] = "=SUM(1099MISC!" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + lastUsedRow_1099MISC + ")";

                        ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(1099INT!" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + lastUsedRow_1099INT + ")";


                        j++;
                    }
                }
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 4, 43] = "Total rows_1099MISC";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 4, 44] = totalrows_1099MISC;
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 43] = "Total rows_1099INT";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 44] = totalrows_1099INT;
                ws_Sheet1.AutoFilterMode = false;
                var range = "AS" + (usedrow + 2) + ":BO" + (usedrow + 3);

                ws_Sheet1.Columns["A:BO"].AutoFit();
                ws_Sheet1.get_Range(range).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Sheet1.get_Range("AS" + (usedrow + 2)).PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_1099INT.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                ws_1099MISC.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                ws_Formula.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_CLA_CLM_Combined.SaveAs(destination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                  excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                var wb_Signoff = excellApp.Workbooks.Add(signofftemplate);
                var ws_Signoff = (excel.Worksheet)wb_Signoff.Worksheets.Item[1];

                ws_Sheet1.get_Range("AR" + (usedrow + 4) + ":AR" + (usedrow + 4)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Sheet1.get_Range("AR" + (usedrow + 5) + ":AR" + (usedrow + 5)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Signoff.Cells[15, 2] = totalrows_1099MISC + totalrows_1099INT;

                ws_Sheet1.get_Range("AS" + (usedrow + 2) + ":BB" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BD" + (usedrow + 2) + ":BE" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BG" + (usedrow + 2) + ":BG" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BI" + (usedrow + 2) + ":BJ" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BL" + (usedrow + 2) + ":BN" + (usedrow + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("E39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Sheet1.get_Range("AS" + (usedrow + 3) + ":BB" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BD" + (usedrow + 3) + ":BE" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BG" + (usedrow + 3) + ":BG" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BI" + (usedrow + 3) + ":BJ" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BL" + (usedrow + 3) + ":BN" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                wb_Signoff.SaveAs(signoffDestination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                 excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_CLA_CLM_Combined.Close();
                wb_Signoff.Close();
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// Extract data from POS_Combined files and paste it into the excel template.Filter according to the form type,Calculate the box values and save the template to the destination folder.
        /// Open Signoff template and copy the calculated box values from the excel template to the Signofftemplate sheet and save it to the destination folder.
        /// </summary>
        /// <param name="source">Path of the source file.</param>
        /// <param name="template">Path of the excel template.</param>
        /// <param name="signoffTemplate">Path of the signoff excel template.</param>
        /// <param name="destination">Path of the destination file name.</param>
        /// <param name="signoffDestination">Path of the signoff Destination filename.</param>
        /// <param name="misValue">Name of the excel object.</param>
        /// <param name="excellApp">Name of the excel application.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void POS_Combined(string source, string template, string signofftemplate, string destination, string signoffDestination, object misValue, excel.Application excellApp, string logFilename)

        {
            try
            {
                //excellApp.Visible = true;
                excellApp.Workbooks.OpenText(source, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                             misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);
                var wb_Text = excellApp.ActiveWorkbook;
                var ws_Text = (excel.Worksheet)wb_Text.Worksheets.Item[1];

                ws_Text.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                var wb_POS_Combined = excellApp.Workbooks.Add(template);
                excel.Sheets excelSheets = wb_POS_Combined.Worksheets;
                excel.Worksheet ws_Sheet1 = (excel.Worksheet)excelSheets.get_Item("Sheet1");
                ws_Sheet1.get_Range("A2").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text.get_Range("A1").Copy();
                wb_Text.Close(SaveChanges: false);

                var lastUsedRow_sheet1 = ws_Sheet1.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                       excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                var usedrow = lastUsedRow_sheet1;
                var totalrows = lastUsedRow_sheet1 - 1;
                excel.Worksheet ws_Formula = (excel.Worksheet)excelSheets.get_Item("formula");
                ws_Formula.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from = ws_Formula.get_Range("A1:A" + usedrow);
                excel.Range to = ws_Sheet1.get_Range("O1:O" + usedrow);
                from.Copy(to);
                //copy the state from n column to AB column
                excel.Range from_st = ws_Sheet1.get_Range("N2:N" + usedrow);
                excel.Range to_st = ws_Sheet1.get_Range("AB2:AB" + usedrow);
                from_st.Copy(to_st);
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, 44] = "Total_1099INT";

                int j = 45;
                for (char Outer = 'A'; Outer <= 'B'; Outer++)
                {
                    for (char Inner = 'S'; Inner <= 'Z'; Inner++)
                    {
                        if (Outer == 'B' && Inner == 'T')
                            break;
                        if (Outer == 'B')
                            for (char Inner1 = 'A'; Inner1 <= 'O'; Inner1++)
                            {
                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + usedrow + ")";

                                if (Inner1 == 'O')
                                    break;
                                else
                                    j++;
                            }
                        else
                            ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + usedrow + ")";


                        j++;
                    }
                }

                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 43] = "Total rows_1099INT";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 44] = totalrows;
                ws_Sheet1.AutoFilterMode = false;
                var range = "AS" + (lastUsedRow_sheet1 + 3) + ":BO" + (lastUsedRow_sheet1 + 3);

                ws_Sheet1.Columns["A:BO"].AutoFit();
                ws_Sheet1.get_Range(range).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Sheet1.get_Range("AS" + (lastUsedRow_sheet1 + 3)).PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Formula.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_POS_Combined.SaveAs(destination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                  excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                var wb_Signoff = excellApp.Workbooks.Add(signofftemplate);
                var ws_Signoff = (excel.Worksheet)wb_Signoff.Worksheets.Item[1];

                ws_Sheet1.get_Range("AR" + (usedrow + 5) + ":AR" + (usedrow + 5)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Signoff.Cells[15, 2] = totalrows;


                ws_Sheet1.get_Range("AS" + (usedrow + 3) + ":BB" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BD" + (usedrow + 3) + ":BE" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BG" + (usedrow + 3) + ":BG" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BI" + (usedrow + 3) + ":BJ" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BL" + (usedrow + 3) + ":BN" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                wb_Signoff.SaveAs(signoffDestination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                 excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_POS_Combined.Close();
                wb_Signoff.Close();
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }

        }


        /// <summary>
        /// Extract data from CLA_POS_1035_1099R files and paste it into the excel template.Filter according to the form type,Calculate the box values and save the template to the destination folder.
        /// Open Signoff template and copy the calculated box values from the excel template to the Signofftemplate sheet and save it to the destination folder.
        /// </summary>
        /// <param name="source">Path of the source file.</param>
        /// <param name="template">Path of the excel template.</param>
        /// <param name="signoffTemplate">Path of the signoff excel template.</param>
        /// <param name="destination">Path of the destination file name.</param>
        /// <param name="signoffDestination">Path of the signoff Destination filename.</param>
        /// <param name="misValue">Name of the excel object.</param>
        /// <param name="excellApp">Name of the excel application.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void CLA_POS_1035_1099R(string source, string template, string signofftemplate, string destination, string signoffDestination, object misValue, excel.Application excellApp, string logFilename)

        {
            try
            {
                excellApp.Workbooks.OpenText(source, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                              misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);
                var wb_Text = excellApp.ActiveWorkbook;
                var ws_Text = (excel.Worksheet)wb_Text.Worksheets.Item[1];

                ws_Text.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                var wb_CLA_POS_1035_1099R = excellApp.Workbooks.Add(template);
                excel.Sheets excelSheets = wb_CLA_POS_1035_1099R.Worksheets;
                excel.Worksheet ws_Sheet1 = (excel.Worksheet)excelSheets.get_Item("Sheet1");
                ws_Sheet1.get_Range("A2").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text.get_Range("A1").Copy();
                wb_Text.Close(SaveChanges: false);

                var lastUsedRow_sheet1 = ws_Sheet1.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                       excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                var usedrow = lastUsedRow_sheet1;
                var totalrows = lastUsedRow_sheet1 - 1;
                excel.Worksheet ws_Formula = (excel.Worksheet)excelSheets.get_Item("formula");
                ws_Formula.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from = ws_Formula.get_Range("A1:A" + usedrow);
                excel.Range to = ws_Sheet1.get_Range("O1:O" + usedrow);
                from.Copy(to);

                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, 44] = "Total_1099R";

                int j = 45;
                for (char Outer = 'A'; Outer <= 'B'; Outer++)
                {
                    for (char Inner = 'S'; Inner <= 'Z'; Inner++)
                    {
                        if (Outer == 'B' && Inner == 'T')
                            break;
                        if (Outer == 'B')
                            for (char Inner1 = 'A'; Inner1 <= 'O'; Inner1++)
                            {
                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + usedrow + ")";

                                if (Inner1 == 'O')
                                    break;
                                else
                                    j++;
                            }
                        else
                            ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + usedrow + ")";


                        j++;
                    }
                }

                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 43] = "Total rows_1099R";
                ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 44] = totalrows;
                ws_Sheet1.AutoFilterMode = false;
                var range = "AS" + (lastUsedRow_sheet1 + 3) + ":BO" + (lastUsedRow_sheet1 + 3);


                ws_Sheet1.Columns["A:BO"].AutoFit();
                ws_Sheet1.get_Range(range).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Sheet1.get_Range("AS" + (lastUsedRow_sheet1 + 3)).PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Formula.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_CLA_POS_1035_1099R.SaveAs(destination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                  excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                var wb_Signoff = excellApp.Workbooks.Add(signofftemplate);
                var ws_Signoff = (excel.Worksheet)wb_Signoff.Worksheets.Item[1];

                ws_Sheet1.get_Range("AR" + (usedrow + 5) + ":AR" + (usedrow + 5)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                ws_Signoff.Cells[15, 2] = totalrows;


                ws_Sheet1.get_Range("AS" + (usedrow + 3) + ":BB" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BD" + (usedrow + 3) + ":BE" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BG" + (usedrow + 3) + ":BG" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BI" + (usedrow + 3) + ":BJ" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Sheet1.get_Range("BL" + (usedrow + 3) + ":BN" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                wb_Signoff.SaveAs(signoffDestination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                 excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_CLA_POS_1035_1099R.Close();
                wb_Signoff.Close();
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }


        /// <summary>
        /// Extract data from POS_1035_1099R files and paste it into the excel template.Filter according to the form type,Calculate the box values and save the template to the destination folder.
        /// Open Signoff template and copy the calculated box values from the excel template to the Signofftemplate sheet and save it to the destination folder.
        /// </summary>
        /// <param name="source">Path of the source file.</param>
        /// <param name="template">Path of the excel template.</param>
        /// <param name="signoffTemplate">Path of the signoff excel template.</param>
        /// <param name="destination">Path of the destination file name.</param>
        /// <param name="signoffDestination">Path of the signoff Destination filename.</param>
        /// <param name="misValue">Name of the excel object.</param>
        /// <param name="excellApp">Name of the excel application.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void POS_1035_1099R(string source, string template, string signofftemplate, string destination, string signoffDestination, object misValue, excel.Application excellApp, string logFilename)

        {
            try
            {
                var wb_POS_1035_1099R = excellApp.Workbooks.Add(template);
                excel.Sheets excelSheets = wb_POS_1035_1099R.Worksheets;
                //string currentSheet = "Sheet1";

                excel.Worksheet WS_POS_1035_1099R =
                    (excel.Worksheet)excelSheets.Item[1];

                //excellApp.Visible = true;
                FileInfo fi = new FileInfo(source);
                if (fi.Length == 0)
                {
                    wb_POS_1035_1099R.SaveAs(destination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
               excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                    var wb_Signoff = excellApp.Workbooks.Add(signofftemplate);
                    var ws_Signoff = (excel.Worksheet)wb_Signoff.Worksheets.Item[1];
                    ws_Signoff.Columns["A:BO"].AutoFit();
                    wb_Signoff.SaveAs(signoffDestination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
               excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                    wb_POS_1035_1099R.Close();
                    wb_Signoff.Close();
                }
                else
                {
                    excellApp.Workbooks.OpenText(source, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
         misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);
                    var wb_Text = excellApp.ActiveWorkbook;
                    var ws_Text = (excel.Worksheet)wb_Text.Worksheets.Item[1];

                    ws_Text.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();

                    excel.Worksheet ws_Sheet1 = (excel.Worksheet)excelSheets.get_Item("Sheet1");
                    ws_Sheet1.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                    ws_Text.get_Range("A1").Copy();
                    wb_Text.Close(SaveChanges: false);

                    var lastUsedRow_sheet1 = ws_Sheet1.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                           excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                    var usedrow = lastUsedRow_sheet1;
                    var totalrows = lastUsedRow_sheet1 - 1;

                    ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, 44] = "Total_1099R";

                    int j = 45;
                    for (char Outer = 'A'; Outer <= 'B'; Outer++)
                    {
                        for (char Inner = 'S'; Inner <= 'Z'; Inner++)
                        {
                            if (Outer == 'B' && Inner == 'T')
                                break;
                            if (Outer == 'B')
                                for (char Inner1 = 'A'; Inner1 <= 'O'; Inner1++)
                                {
                                    ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(" + Outer.ToString() + Inner1.ToString() + "2:" + Outer.ToString() + Inner1.ToString() + usedrow + ")";

                                    if (Inner1 == 'O')
                                        break;
                                    else
                                        j++;
                                }
                            else
                                ws_Sheet1.Cells[lastUsedRow_sheet1 + 3, j] = "=SUM(" + Outer.ToString() + Inner.ToString() + "2:" + Outer.ToString() + Inner.ToString() + usedrow + ")";


                            j++;
                        }
                    }

                    ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 43] = "Total rows_1099INT";
                    ws_Sheet1.Cells[lastUsedRow_sheet1 + 5, 44] = totalrows;
                    ws_Sheet1.AutoFilterMode = false;
                    var range = "AS" + (lastUsedRow_sheet1 + 3) + ":BO" + (lastUsedRow_sheet1 + 3);
                    ws_Sheet1.Columns["A:BO"].AutoFit();
                    ws_Sheet1.get_Range(range).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                    ws_Sheet1.get_Range("AS" + (lastUsedRow_sheet1 + 3)).PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                    wb_POS_1035_1099R.SaveAs(destination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                      excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                    var wb_Signoff = excellApp.Workbooks.Add(signofftemplate);
                    var ws_Signoff = (excel.Worksheet)wb_Signoff.Worksheets.Item[1];

                    ws_Sheet1.get_Range("AR" + (usedrow + 5) + ":AR" + (usedrow + 5)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                    ws_Signoff.get_Range("B21").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                    ws_Signoff.Cells[15, 2] = totalrows;


                    ws_Sheet1.get_Range("AS" + (usedrow + 3) + ":BB" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                    ws_Signoff.get_Range("B24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                    ws_Sheet1.get_Range("BD" + (usedrow + 3) + ":BE" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                    ws_Signoff.get_Range("B34").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                    ws_Sheet1.get_Range("BG" + (usedrow + 3) + ":BG" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                    ws_Signoff.get_Range("B36").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                    ws_Sheet1.get_Range("BI" + (usedrow + 3) + ":BJ" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                    ws_Signoff.get_Range("B37").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                    ws_Sheet1.get_Range("BL" + (usedrow + 3) + ":BN" + (usedrow + 3)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                    ws_Signoff.get_Range("B39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                    wb_Signoff.SaveAs(signoffDestination, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                     excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                    wb_POS_1035_1099R.Close();
                    wb_Signoff.Close();

                }
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// Compress the output files to the zipfolder.Attach the zipfolder and send mail 
        /// </summary>
        /// <param name="output_CLM_Combined">Path of output files folder.</param>
        /// /// <param name="output_POS_1035_1099R">Path of output files folder.</param>
        /// /// <param name="output_POS_Combined">Path of output files folder.</param>
        /// <param name="mail_From">Sender of the Mail.</param>
        /// <param name="mailTo_CLM_Combined">Receiver names of the Mail.</param>
        /// <param name="Mail_CC">CC names of the Mail.</param>
        /// <param name="logFilename">Name of the file name.</param>
        /// <param name="htmlFilePath">Path of the html file.</param>
        /// <param name="zipfile_CLMandCLA_CLM">Path of the zipfolder.</param>
        ///  /// <param name="mailTo_POS_1035_1099R">Receiver names of the Mail.</param>
        /// /// <param name="zipfile_CLA_POSandPOS_1035_1099R">Path of the zipfolder.</param>
        /// ///  /// <param name="mailTo_POS_Combined">Receiver names of the Mail.</param>
        /// /// <param name="zipfile_CLA_POSandPOS">Path of the zipfolder.</param>
        private static void sendmail(string mail_From, string output_CLM_Combined, string mailTo_CLM_Combined, string Mail_CC,
   string output_POS_1035_1099R, string mailTo_POS_1035_1099R, string output_POS_Combined, string mailTo_POS_Combined, string html, string logFilename,
   string zipfile_CLMandCLA_CLM, string zipfile_CLA_POSandPOS, string zipfile_CLA_POSandPOS_1035_1099R)
        {

            // mail to be send with multiple attachment
            DirectoryInfo CLM_Combined_op = new DirectoryInfo(output_CLM_Combined);
            FileInfo[] CLM_Combined_excel = CLM_Combined_op.GetFiles("*.xlsx");

            DirectoryInfo POS_1035_1099R_op = new DirectoryInfo(output_POS_1035_1099R);
            FileInfo[] POS_1035_1099R_excel = POS_1035_1099R_op.GetFiles("*.xlsx");

            DirectoryInfo POS_Combined_op = new DirectoryInfo(output_POS_Combined);
            FileInfo[] POS_Combined_excel = POS_Combined_op.GetFiles("*.xlsx");

            try
            {
                // CLA_CLM_Combined_CLM_Combined
                if (CLM_Combined_excel.Length != 0)
                {
                    using (StreamReader reader = File.OpenText(html)) // Path to your 
                    {                                                         // HTML file
                        ZipFile.CreateFromDirectory(output_CLM_Combined, zipfile_CLMandCLA_CLM, CompressionLevel.Fastest, true);
                        Console.WriteLine("CLA_CLM_Combined and CLM_Combined Zip file Create Successfully!! ");
                        System.Net.Mail.MailMessage mail_CLM_Combined = new System.Net.Mail.MailMessage();
                        mail_CLM_Combined.Attachments.Add(new Attachment(zipfile_CLMandCLA_CLM));
                        mail_CLM_Combined.Subject = "CLA_CLM_Combined and CLM_Combined files";
                        mail_CLM_Combined.IsBodyHtml = true;
                        mail_CLM_Combined.Body = reader.ReadToEnd();
                        mail_CLM_Combined.From = new MailAddress(mail_From);
                        foreach (var toaddress in mailTo_CLM_Combined.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_CLM_Combined.To.Add(toaddress);
                        foreach (var ccaddress in Mail_CC.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_CLM_Combined.CC.Add(ccaddress);
                        SmtpClient smtpServer = new SmtpClient("caeemail.unum.com");
                        smtpServer.Send(mail_CLM_Combined);
                        mail_CLM_Combined.Attachments.Dispose();
                        Console.WriteLine("CLA_CLM_Combined and CLM_Combined Mail sent successfully");
                        WriteLog(logFilename, "CLA_CLM_Combined and CLM_Combined Mail sent successfully" + DateTime.Now.ToString());
                        File.Delete(zipfile_CLMandCLA_CLM);
                        WriteLog(logFilename, "-----------------------------------------------------------------");
                    }
                }
                else
                    WriteLog(logFilename, "File doesnot exists.so CLA_CLM_Combined and CLM_Combined mail not sent." + DateTime.Now.ToString());
                WriteLog(logFilename, "-----------------------------------------------------------------");

                //CLA_POS_1035_1099R_POS_1035_1099R mail
                if (POS_1035_1099R_excel.Length != 0)
                {
                    using (StreamReader reader = File.OpenText(html)) // Path to your 
                    {                                                         // HTML file
                        ZipFile.CreateFromDirectory(output_POS_1035_1099R, zipfile_CLA_POSandPOS_1035_1099R, CompressionLevel.Fastest, true);
                        Console.WriteLine("CLA_POS_1035_1099R and POS_1035_1099R Zip file Create Successfully!! ");
                        System.Net.Mail.MailMessage mail_POS_1035_1099R = new System.Net.Mail.MailMessage();
                        mail_POS_1035_1099R.Attachments.Add(new Attachment(zipfile_CLA_POSandPOS_1035_1099R));
                        mail_POS_1035_1099R.Subject = "CLA_POS_1035_1099R and POS_1035_1099R ";
                        mail_POS_1035_1099R.IsBodyHtml = true;
                        mail_POS_1035_1099R.Body = reader.ReadToEnd();
                        mail_POS_1035_1099R.From = new MailAddress(mail_From);
                        foreach (var toaddress in mailTo_POS_1035_1099R.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_POS_1035_1099R.To.Add(toaddress);
                        foreach (var ccaddress in Mail_CC.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_POS_1035_1099R.CC.Add(ccaddress);
                        SmtpClient smtpServer = new SmtpClient("caeemail.unum.com");
                        smtpServer.Send(mail_POS_1035_1099R);
                        mail_POS_1035_1099R.Attachments.Dispose();
                        Console.WriteLine("CLA_POS_1035_1099R and POS_1035_1099R Mail sent successfully");
                        WriteLog(logFilename, "CLA_POS_1035_1099R and POS_1035_1099R Mail sent successfully" + DateTime.Now.ToString());
                        File.Delete(zipfile_CLA_POSandPOS_1035_1099R);
                        WriteLog(logFilename, "-----------------------------------------------------------------");
                    }
                }
                else
                    WriteLog(logFilename, "File doesnot exists.so CLA_POS_1035_1099R and POS_1035_1099R mail not sent." + DateTime.Now.ToString());
                WriteLog(logFilename, "-----------------------------------------------------------------");

                //CLA_POS_POS_Combined
                if (POS_Combined_excel.Length != 0)
                {
                    using (StreamReader reader = File.OpenText(html)) // Path to your 
                    {                                                         // HTML file
                        ZipFile.CreateFromDirectory(output_POS_Combined, zipfile_CLA_POSandPOS, CompressionLevel.Fastest, true);
                        Console.WriteLine("CLA_POS_1035_1099R and POS_1035_1099R Zip file Create Successfully!! ");
                        System.Net.Mail.MailMessage mailPOS_Combined_excel = new System.Net.Mail.MailMessage();
                        mailPOS_Combined_excel.Attachments.Add(new Attachment(zipfile_CLA_POSandPOS));
                        mailPOS_Combined_excel.Subject = "CLA_POS and POS_Combined files";
                        mailPOS_Combined_excel.IsBodyHtml = true;
                        mailPOS_Combined_excel.Body = reader.ReadToEnd();
                        mailPOS_Combined_excel.From = new MailAddress(mail_From);
                        foreach (var toaddress in mailTo_POS_Combined.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mailPOS_Combined_excel.To.Add(toaddress);
                        foreach (var ccaddress in Mail_CC.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mailPOS_Combined_excel.CC.Add(ccaddress);
                        SmtpClient smtpServer = new SmtpClient("caeemail.unum.com");
                        smtpServer.Send(mailPOS_Combined_excel);
                        mailPOS_Combined_excel.Attachments.Dispose();
                        Console.WriteLine("CLA_POS and POS_Combined files Mail sent successfully");
                        WriteLog(logFilename, "CLA_POS and POS_Combined files Mail sent successfully" + DateTime.Now.ToString());
                        File.Delete(zipfile_CLA_POSandPOS);
                        WriteLog(logFilename, "-----------------------------------------------------------------");
                    }
                }
                else
                    WriteLog(logFilename, "File doesnot exists.so CLA_POS and POS_Combined files mail not sent." + DateTime.Now.ToString());
                WriteLog(logFilename, "-----------------------------------------------------------------");

            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        ///Move the inputfiles to input archieve path
        ///Move the output files to output archieve path
        /// </summary>
        /// <param name="inputFilepath">path of the input folder</param>
        /// <param name="inputArchivepath">path of the input archieve folder</param>
        /// <param name="outputFilepath">Path of the output folder</param>
        /// <param name="dstnpath_CLA_CLM_Combined_CLM_Combined">path of the CLA_CLM_Combined_CLM_Combined output folder</param>
        /// <param name="dstnpath_CLA_POS_1035_1099R_POS_1035_1099R">path of the CLA_POS_1035_1099R_POS_1035_1099R output folder</param>
        /// <param name="dstnpath_CLA_POS_POS_Combined">path of the CLA_POS_POS_Combined output folder</param>
        /// <param name="outputArchivepath">Path of the output archieve folder</param>
        /// <param name="logFilename">Name of the logfile.</param>
        static void MoveInput_OutputfilesToArchive(string inputFilepath, string inputArchivepath, string dstnpath_CLA_CLM_Combined_CLM_Combined,
            string dstnpath_CLA_POS_1035_1099R_POS_1035_1099R, string dstnpath_CLA_POS_POS_Combined, string outputArchivepath, string logFilename)
        {
            string[] inputfiles = Directory.GetFiles(inputFilepath);
            string[] dstnpath1 = Directory.GetFiles(dstnpath_CLA_CLM_Combined_CLM_Combined);
            string[] dstnpath2 = Directory.GetFiles(dstnpath_CLA_POS_1035_1099R_POS_1035_1099R);
            string[] dstnpath3 = Directory.GetFiles(dstnpath_CLA_POS_POS_Combined);

            foreach (var inputfile in inputfiles)
            {
                File.Move(inputfile, $"{inputArchivepath}{Path.GetFileNameWithoutExtension(inputfile)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(inputfile));
                WriteLog(logFilename, inputfile + "moved to inputarchievepath");
                Console.WriteLine(inputfile + "moved to inputarchievepath");
            }

            foreach (var dstn1file in dstnpath1)
            {
                File.Move(dstn1file, $"{outputArchivepath}{Path.GetFileNameWithoutExtension(dstn1file)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(dstn1file));
                WriteLog(logFilename, dstn1file + "moved to outputarchievepath");
                Console.WriteLine(dstn1file + "moved to outputarchievepath");
            }

            foreach (var dstn2file in dstnpath2)
            {
                File.Move(dstn2file, $"{outputArchivepath}{Path.GetFileNameWithoutExtension(dstn2file)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(dstn2file));
                WriteLog(logFilename, dstn2file + "moved to outputarchievepath");
                Console.WriteLine(dstn2file + "moved to outputarchievepath");
            }

            foreach (var dstn3file in dstnpath3)
            {
                File.Move(dstn3file, $"{outputArchivepath}{Path.GetFileNameWithoutExtension(dstn3file)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(dstn3file));
                WriteLog(logFilename, dstn3file + "moved to outputarchievepath");
                Console.WriteLine(dstn3file + "moved to outputarchievepath");
            }


        }

        /// <summary>
        /// write the logs.
        /// </summary>
        /// <param name="logFilename">Name of the logfile.</param>
        public static void WriteLog(String logFilename, string text)
        {
            try
            {
                if (!File.Exists(logFilename))
                {
                    File.Create(logFilename).Close();
                }
                using (StreamWriter logwrite = new StreamWriter(logFilename, true))
                {
                    logwrite.WriteLine(string.Format(text));
                    logwrite.Close();
                }
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
            }
        }
    }
}
