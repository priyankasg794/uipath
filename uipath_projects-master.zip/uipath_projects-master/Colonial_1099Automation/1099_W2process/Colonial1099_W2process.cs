﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using System.Net.Mail;
using System.IO.Compression;
using outlook = Microsoft.Office.Interop.Outlook;
using System.Net;
using Microsoft.Office.Interop.Word;


namespace _1099_W2process
{
    /// <summary>
	/// W2 process class gets the text files from the mainframe and convert the text files into excel and document, then format it and save to the destination folder.
    /// Attach the output files and send mail.Move input and output files to archieve path.
	/// </summary>
    class Colonial1099_W2process
    {
        static void Main(string[] args)
        {

            string alertmailFrom = ConfigurationManager.AppSettings["AlertMail_FromAddress"].ToString();
            string alertmailTo = ConfigurationManager.AppSettings["AlertMail_ToAddress"].ToString();
            string alertmailCc = ConfigurationManager.AppSettings["AlertMail_CCAddress"].ToString();
            string mailFrom = ConfigurationManager.AppSettings["Mail_FromAddress"].ToString();
            string mailTo = ConfigurationManager.AppSettings["Mail_ToAddress"].ToString();
            string mailCC = ConfigurationManager.AppSettings["Mail_CCAddress"].ToString();
            string logPath = ConfigurationManager.AppSettings["Logs"].ToString();
            string logFilename = logPath + "Logs -" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
            string w2rFilepath = ConfigurationManager.AppSettings["W2Rfilepath"].ToString();
            string w2fFilepath = ConfigurationManager.AppSettings["W2Ffilepath"].ToString();
            string alphafoundFilepath = ConfigurationManager.AppSettings["Alphafoundfilepath"].ToString();
            string alphanotfoundFilepath = ConfigurationManager.AppSettings["Alphanotfoundfilepath"].ToString();
            string clms_prior_reversals_Path = ConfigurationManager.AppSettings["CLMS_PRIOR_YEAR_REVERSALSpath"].ToString();
            string exceltemplatePath = ConfigurationManager.AppSettings["Exceltemplatepath"].ToString();
            string htmlFile = ConfigurationManager.AppSettings["HTMLfile"].ToString();
            string alertHtmlfile = ConfigurationManager.AppSettings["AlertHTMLfile"].ToString();
            string outputFilepath = ConfigurationManager.AppSettings["Outputfile"].ToString();
            string outputFilename = outputFilepath + "POS_W2R&W2F_Combined_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string alphafoundFilename = outputFilepath + "ALPHA_FOUND_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string alphanotfoundFilename = outputFilepath + "ALPHA_NOT_FOUND_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string clms_prior_reversals_Filename = outputFilepath + "CLMS_PRIOR_YEAR_REVERSALS_" + DateTime.Now.ToString("yyyy") + ".xlsx";
            string inputFilepath = ConfigurationManager.AppSettings["Inputfile"].ToString();
            string inputArchivepath = ConfigurationManager.AppSettings["Inputarchivepath"].ToString();
            string outputArchivepath = ConfigurationManager.AppSettings["Outputarchivepath"].ToString();
            string signoff_Template = ConfigurationManager.AppSettings["signoff_template"].ToString();
            string destinationSignoff = outputFilepath + "Sign Off for Year End " + DateTime.Now.ToString("yyyy") + "Tax Files - POS_W2R&W2F_Combined" + ".xlsx";
            string zipFilepath = ConfigurationManager.AppSettings["zipfilepath"].ToString();
            string zipFile = zipFilepath + "1099 W2files" + DateTime.Now.ToString("yyyy") + ".zip";


            try
            {
                DirectoryInfo di = new DirectoryInfo(inputFilepath);
                FileInfo[] TXTFiles = di.GetFiles("*.txt");
                FileInfo[] DocFiles = di.GetFiles("*.doc");

                if (TXTFiles.Length != 0 || DocFiles.Length != 0)
                {
                    var lineCount_W2R = File.ReadLines(inputFilepath + "W2R.TXT").Count();
                    var lineCount_W2F = File.ReadLines(inputFilepath + "W2F.TXT").Count();
                    if (lineCount_W2R != lineCount_W2F)
                    {
                        SendAlertMail(alertmailFrom, alertmailTo, alertmailCc, logFilename, alertHtmlfile);
                    }
                    else
                    {
                        Convert_TextfiletoExcel(exceltemplatePath, outputFilename, w2rFilepath, w2fFilepath, logFilename, signoff_Template, destinationSignoff);

                        Worddoc_Conversion(inputFilepath, outputFilepath, logFilename);

                        Convert_Alpha_CLMSfilestoExcel(alphafoundFilename, alphanotfoundFilename, clms_prior_reversals_Filename, clms_prior_reversals_Path,
                                                             alphafoundFilepath, alphanotfoundFilepath, logFilename);

                        SendMail(outputFilepath, mailFrom, mailTo, mailCC, logFilename, htmlFile, zipFile);

                        MoveInputToArchive(inputFilepath, inputArchivepath, logFilename);

                        MoveOutputToArchive(outputFilepath, outputArchivepath, logFilename);
                    }
                }
                else
                    WriteLog(logFilename, "File does not exist" + DateTime.Now.ToString());
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
		/// Extract data from W2R and W2F files and paste it into the excel template.Calculate the box values and save the template to the destination folder.
        /// Open Signoff template and copy the calculated box values from the excel template to the Signofftemplate sheet and save it to the destination folder.
		/// </summary>
		/// <param name="exceltemplatePath">Path of the excel template.</param>
		/// <param name="excelFilename">Name of the output excel file name.</param>
		/// <param name="w2rFilepath">Path of the W2R file.</param>
        /// <param name="w2fFilepath">Path of the W2F file.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        /// <param name="signoff_Template">Path of the signoff Template.</param>
        /// <param name="destinationSignoff">Name of the Sign off excel output .</param>
        private static void Convert_TextfiletoExcel(string exceltemplatePath, string excelFilename, string w2rFilepath, string w2fFilepath, string logFilename, string signoff_Template, string destinationSignoff)
        {
            try
            {

                Microsoft.Office.Interop.Excel.Application excellApp = new Microsoft.Office.Interop.Excel.Application();
                object misValue = System.Reflection.Missing.Value;
                //excellApp.Visible = true;

                var excellWorkBook = excellApp.Workbooks.Add(exceltemplatePath);
                var excellWorkSheet = (excel.Worksheet)excellWorkBook.Worksheets.Item[1];


                excellApp.Workbooks.OpenText(w2rFilepath, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                 misValue, misValue, misValue, true, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_W2Rtext = excellApp.ActiveWorkbook;
                var wS_W2Rtext = (excel.Worksheet)wb_W2Rtext.Worksheets.Item[1];

                wS_W2Rtext.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                excellWorkSheet.get_Range("A2").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                wS_W2Rtext.get_Range("A1").Copy();
                wb_W2Rtext.Close(SaveChanges: false);

                excellApp.Workbooks.OpenText(w2fFilepath, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                misValue, misValue, misValue, true, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_W2Ftext = excellApp.ActiveWorkbook;
                var wS_W2Ftext = (excel.Worksheet)wb_W2Ftext.Worksheets.Item[1];
                wS_W2Ftext.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                excellWorkSheet.get_Range("L2").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                wS_W2Ftext.get_Range("A1").Copy();
                wb_W2Ftext.Close(SaveChanges: false);

                var lastUsedRow_sheet1 = excellWorkSheet.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                               excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                excel.Worksheet ws_Formula = (excel.Worksheet)excellWorkBook.Worksheets.Item[2];
                ws_Formula.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from = ws_Formula.get_Range("A1:A" + lastUsedRow_sheet1);
                excel.Range to = excellWorkSheet.get_Range("H1:H" + lastUsedRow_sheet1);
                from.Copy(to);

                ws_Formula.get_Range("B1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 2].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from1 = ws_Formula.get_Range("B1:B" + lastUsedRow_sheet1);
                excel.Range to1 = excellWorkSheet.get_Range("K1:K" + lastUsedRow_sheet1);
                from1.Copy(to1);


                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 19] = "Total";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 20] = "=SUM(T2:T" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 21] = "=SUM(U2:U" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 22] = "=SUM(V2:V" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 23] = "=SUM(W2:W" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 24] = "=SUM(X2:X" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 25] = "=SUM(Y2:Y" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 26] = "=SUM(Z2:Z" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 27] = "=SUM(AA2:AA" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 28] = "=SUM(AB2:AB" + lastUsedRow_sheet1 + ")";
                excellWorkSheet.Cells[lastUsedRow_sheet1 + 2, 29] = "=SUM(AC2:AC" + lastUsedRow_sheet1 + ")";

                var totalRows = lastUsedRow_sheet1 - 1;
                ws_Formula.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                var range = "T" + (lastUsedRow_sheet1 + 2) + ":AC" + (lastUsedRow_sheet1 + 2);

                excellWorkSheet.get_Range(range).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                excellWorkSheet.get_Range("T" + (lastUsedRow_sheet1 + 2)).PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);

                excellWorkBook.SaveAs(excelFilename, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                  excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                //sign off form
                var wb_Signoff = excellApp.Workbooks.Add(signoff_Template);
                var ws_Signoff = (excel.Worksheet)wb_Signoff.Worksheets.Item[1];

                excellWorkSheet.get_Range("T" + (lastUsedRow_sheet1 + 2) + ":Y" + (lastUsedRow_sheet1 + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B24").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);
                ws_Signoff.Cells[15, 2] = totalRows;

                excellWorkSheet.get_Range("Z" + (lastUsedRow_sheet1 + 2) + ":AB" + (lastUsedRow_sheet1 + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B39").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                excellWorkSheet.get_Range("AC" + (lastUsedRow_sheet1 + 2) + ":AC" + (lastUsedRow_sheet1 + 2)).SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Signoff.get_Range("B35").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, true);

                wb_Signoff.SaveAs(destinationSignoff, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                 excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                excellWorkBook.Close();
                wb_Signoff.Close();

                excellApp.Quit();

                WriteLog(logFilename, "Excel created" + DateTime.Now.ToString());
                Console.WriteLine("File created !");
                WriteLog(logFilename, excelFilename + "- file converted and excel file generated" + " -- " + DateTime.Now);
            }

            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }

        }

        /// <summary>
        /// Extract data from the Alphafound,Alphanotfound and  ClmsPriorYearReversals file to excel and the save the excel files to the destination folder.
        /// </summary>
        /// <param name="alphafoundOutput">Name of the alphafound output filename.</param>
        /// <param name="alphanotfoundOutput">Name of the alphanotfound output filename.</param>
        /// <param name="clmsOutput">Name of the ClmsPriorYearReversals output file name.</param>
        /// <param name="clmsFile">Path of the ClmsPriorYearReversals file.</param>
        /// <param name="alphafoundFile">Path of the Aphafound file.</param>
        /// <param name="alphanotfoundFile">Path of the Alphanotfound file.</param>
        /// <param name="logFilename">Name of the logfile</param>
        private static void Convert_Alpha_CLMSfilestoExcel(string alphafoundOutput, string alphanotfoundOutput, string clmsOutput, string clmsFile, string alphafoundFile, string alphanotfoundFile, string logFilename)
        {
            try
            {

                Microsoft.Office.Interop.Excel.Application excellApp = new Microsoft.Office.Interop.Excel.Application();
                object misValue = System.Reflection.Missing.Value;
                // excellApp.Visible = true;

                excellApp.Workbooks.OpenText(alphafoundFile, misValue, 1, excel.XlTextParsingType.xlFixedWidth, excel.XlTextQualifier.xlTextQualifierNone,
                 misValue, misValue, misValue, true, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue);

                var Wb_alphafound = excellApp.ActiveWorkbook;
                var WS_alphafound = (excel.Worksheet)Wb_alphafound.Worksheets.Item[1];

                Wb_alphafound.SaveAs(alphafoundOutput, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
              excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                Wb_alphafound.Close();

                excellApp.Workbooks.OpenText(alphanotfoundFile, misValue, 1, excel.XlTextParsingType.xlFixedWidth, excel.XlTextQualifier.xlTextQualifierNone,
                 misValue, misValue, misValue, true, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue);

                var Wb_alphanotfound = excellApp.ActiveWorkbook;
                var WS_alphanotfound = (excel.Worksheet)Wb_alphanotfound.Worksheets.Item[1];

                Wb_alphanotfound.SaveAs(alphanotfoundOutput, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
              excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                Wb_alphanotfound.Close();

                excellApp.Workbooks.OpenText(clmsFile, misValue, 1, excel.XlTextParsingType.xlFixedWidth, excel.XlTextQualifier.xlTextQualifierNone,
                misValue, misValue, misValue, true, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue, misValue);

                var Wb_CLMS = excellApp.ActiveWorkbook;
                var WS_CLMS = (excel.Worksheet)Wb_CLMS.Worksheets.Item[1];

                Wb_CLMS.SaveAs(clmsOutput, excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
              excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                Wb_CLMS.Close();
                excellApp.Quit();
                excellApp.Quit();

            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// Move the input files to the archieve path
        /// </summary>      
        /// <param name="inputFilepath">Path of the input folder.</param>
        /// <param name="inputArchivepath">Path of the input archieve folder.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        static void MoveInputToArchive(string inputFilepath, string inputArchivepath, string logFilename)
        {
            string[] inputFiles = Directory.GetFiles(inputFilepath);

            foreach (var inputfile in inputFiles)
            {
                File.Move(inputfile, $"{inputArchivepath}{Path.GetFileNameWithoutExtension(inputfile)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(inputfile));
                WriteLog(logFilename, "Document files moved to output folder");
                Console.WriteLine("inputfile moved");

            }
        }

        /// <summary>
        /// Move output files to the archieve path
        /// </summary>      
        ///   <param name="outputFilepath">Path of the output folder.</param>
        ///   <param name="outputArchivepath">Path of the output archieve folder.</param>
        ///   <param name="logFilename">Name of the logfile.</param>
        static void MoveOutputToArchive(string outputFilepath, string outputArchivepath, string logFilename)
        {
            string[] outputFiles = Directory.GetFiles(outputFilepath);

            foreach (var outputFile in outputFiles)
            {

                File.Move(outputFile, $"{outputArchivepath}{Path.GetFileNameWithoutExtension(outputFile)}" + DateTime.Now.ToString("hhmmss"));
                WriteLog(logFilename, "Document files moved to output folder");
                Console.WriteLine("outputfile moved");

            }

        }

        /// <summary>
        /// covert the W2_CL_AUDIT_F,W2_CL_MULTI_STATE_F,W2_CL_SUMMARY_F,W2_CL_ZEROS_STATES_F,W2_FICA_WITHHOLDING,W2_PROD _STATES_REPORT,W2_PROD_AUDIT_REPORT,W2_PROD_MULTISTATE_REPORT,W2_PROD_SUMMARY_REPORT,W2_TAX_EXTRACT_REPORT into docx format
        /// change the orientation to landscape and size to legal and save the files in the destination folder
        /// </summary>
        /// <param name="inputfilepath">Path of the input text files folder.</param>
        /// <param name="outputfilepath">Path of the output folder.</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void Worddoc_Conversion(string inputFilepath, string outputFilepath, string logFilename)
        {
            try
            {
                Microsoft.Office.Interop.Word.Application wordapp = new Microsoft.Office.Interop.Word.Application();
                object docmisValue = System.Reflection.Missing.Value;
                //wordapp.Visible = true;
                var wordFiles = Directory.GetFiles(inputFilepath, "*.txt", SearchOption.AllDirectories);

                foreach (var file in wordFiles)
                {

                    if (file == inputFilepath + "W2F.txt" || file == inputFilepath + "W2R.txt" || file == inputFilepath + "W2R.TXT" || file == inputFilepath + "W2F.TXT" || file == inputFilepath + "CLMS_PRIOR_YEAR_REVERSALS.txt" || file == inputFilepath + "CLMS_PRIOR_YEAR_REVERSALS.TXT"
                        || file == inputFilepath + "ALPHA_FOUND.txt" || file == inputFilepath + "ALPHA_FOUND.TXT" || file == inputFilepath + "ALPHA_NOT_FOUND.txt" || file == inputFilepath + "ALPHA_NOT_FOUND.TXT")
                    { }
                    else
                    {
                        string readFile = File.ReadAllText(file);
                        readFile = readFile.Remove(0, 1);
                        File.WriteAllText(file, readFile);
                        Document document = wordapp.Documents.Open(file);
                        string newFileName = document.FullName.Replace(".txt", ".docx");


                        string docFilename = outputFilepath + Path.GetFileNameWithoutExtension(newFileName) + "_" + DateTime.Now.ToString("yyyy");
                        document.PageSetup.PaperSize = WdPaperSize.wdPaperLegal;

                        document.PageSetup.Orientation = WdOrientation.wdOrientLandscape;


                        object savechanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                        document.SaveAs2(docFilename, WdSaveFormat.wdFormatXMLDocument,
                                        CompatibilityMode: WdCompatibilityMode.wdWord2010);

                        WriteLog(logFilename, docFilename + "is converted to landscape mode");
                        Console.WriteLine(docFilename + "is converted to landscape mode");
                        wordapp.ActiveDocument.Close();
                    }

                }

                wordapp.Quit();
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// Compress the output files to the zipfolder.Attach the zipfolder and send mail 
        /// </summary>
        /// <param name="outputfilepath">Path of output files folder.</param>
        /// <param name="MailFrom">Sender of the Mail.</param>
        /// <param name="MailTo">Receiver names of the Mail.</param>
        /// <param name="MailCC">CC names of the Mail.</param>
        /// <param name="logFilename">Name of the file name.</param>
        /// <param name="htmlFilePath">Path of the html file.</param>
        /// <param name="zipfile">Path of the zipfolder.</param>

        private static void SendMail(string outputfilepath, string MailFrom, string MailTo, string MailCC, string logFilename, string htmlFilePath, string zipfile)
        {

            // mail to be send with multiple attachment
            DirectoryInfo op = new DirectoryInfo(outputfilepath);
            FileInfo[] oexcelFiles = op.GetFiles("*.xlsx");
            FileInfo[] oDocFiles = op.GetFiles("*.docx");
            try
            {
                if (oexcelFiles.Length != 0 || oDocFiles.Length != 0)
                {
                    using (StreamReader reader = File.OpenText(htmlFilePath)) // Path to your 
                    {                                                         // HTML file

                        ZipFile.CreateFromDirectory(outputfilepath, zipfile, CompressionLevel.Fastest, true);

                        Console.WriteLine("Zip file Create Successfully!! ");
                        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
                        mail.Attachments.Add(new Attachment(zipfile));
                        mail.Subject = "1099 Auto Mail-W2 Extract docs";
                        mail.IsBodyHtml = true;
                        mail.Body = reader.ReadToEnd();
                        mail.From = new MailAddress(MailFrom);
                        foreach (var toaddress in MailTo.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail.To.Add(toaddress);
                        foreach (var ccaddress in MailCC.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail.CC.Add(ccaddress);
                        SmtpClient smtpServer = new SmtpClient("caeemail.unum.com");
                        smtpServer.Send(mail);
                        mail.Attachments.Dispose();
                        Console.WriteLine("Mail sent successfully");
                        WriteLog(logFilename, "Mail sent successfully" + DateTime.Now.ToString());
                        File.Delete(zipfile);
                        WriteLog(logFilename, "-----------------------------------------------------------------");
                    }
                }
                else
                    WriteLog(logFilename, "File doesnot exists.so mail not sent." + DateTime.Now.ToString());
                WriteLog(logFilename, "-----------------------------------------------------------------");

            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// send alert mail to the respective team if number of rows in the W2R and W2F files are not equal
        /// </summary>
        /// <param name="MailFrom">Sender of the Mail.</param>
        /// <param name="MailTo">Receiver names of the Mail.</param>
        /// <param name="MailCC">CC names of the Mail.</param>
        /// <param name="logFilename">Name of the file name.</param>
        /// <param name="htmlFilePath">Path of the html file.</param>
        private static void SendAlertMail(string MailFrom, string MailTo, string MailCC, string logFilename, string htmlFilePath)
        {

            try
            {

                using (StreamReader reader = File.OpenText(htmlFilePath)) // Path to your 
                {                                                         // HTML file

                    System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();

                    mail.Subject = "1099 Auto W2 Extract doc-Alert Mail ";
                    mail.IsBodyHtml = true;
                    mail.Body = reader.ReadToEnd();
                    mail.From = new MailAddress(MailFrom);
                    foreach (var toaddress in MailTo.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                        mail.To.Add(toaddress);
                    foreach (var ccaddress in MailCC.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                        mail.CC.Add(ccaddress);
                    SmtpClient smtpServer = new SmtpClient("caeemail.unum.com");
                    smtpServer.Send(mail);
                    mail.Attachments.Dispose();
                    Console.WriteLine("Mail sent successfully");
                    WriteLog(logFilename, "Mail sent successfully" + DateTime.Now.ToString());
                    WriteLog(logFilename, "-----------------------------------------------------------------");
                }


            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// write the logs.
        /// </summary>
        /// <param name="logFilename">Name of the logfile.</param>
        public static void WriteLog(String logFilename, string text)
        {
            try
            {
                if (!File.Exists(logFilename))
                {
                    File.Create(logFilename).Close();
                }
                using (StreamWriter logwrite = new StreamWriter(logFilename, true))
                {
                    logwrite.WriteLine(string.Format(text));
                    logwrite.Close();
                }
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
            }
        }
    }
}
