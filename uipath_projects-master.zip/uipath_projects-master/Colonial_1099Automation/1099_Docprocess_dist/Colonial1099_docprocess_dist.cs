﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Net.Mail;
using System.IO.Compression;
using System.Net;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;
using excel = Microsoft.Office.Interop.Excel;

namespace _1099_Docprocess_dist
{
    class Colonial1099_docprocess_dist
    {
        /// <summary>
        /// Colonial_1099docprocess_dist class gets the text files from the mainframe and convert the text files into excel and document, then format it and save to the destination folder.
        /// Extract the data from the text file and copy the data to the destination text file.
        /// Attach the output files and send mail.Move input and output files to archieve path.
        /// </summary>
        public static void Main(string[] args)
        {
            string destinationFilepath = ConfigurationManager.AppSettings["destinationpath"].ToString();
            string inputPath = ConfigurationManager.AppSettings["inputpath"].ToString();
            string inputArchive_path = ConfigurationManager.AppSettings["inputarchive_path"].ToString();
            string outputArchive_path = ConfigurationManager.AppSettings["outputarchive_path"].ToString();
            string lincoln_Outputpath = ConfigurationManager.AppSettings["Lincoln_Docs_outputpath"].ToString();
            string william_penn_Outputpath = ConfigurationManager.AppSettings["William_Penn_Docs_outputpath"].ToString();
            string Vendor_Outputpath = ConfigurationManager.AppSettings["Vendor_Docs_outputpath"].ToString();

            string template_TLNCSIGN = ConfigurationManager.AppSettings["TLNCSIGN_template"].ToString();
            string destinationfile_TLNCSIGN = destinationFilepath + "TLNCSIGN.txt";
            string path_LINCDRPT = ConfigurationManager.AppSettings["LINCDRPT_path"].ToString();

            string template_PLNCSIN2 = ConfigurationManager.AppSettings["PLNCSIN2_template"].ToString();
            string destinationfile_PLNCSIN2 = destinationFilepath + "PLNCSIN2.txt";
            string path_ARGAMLNL = ConfigurationManager.AppSettings["ARGAMLNL_path"].ToString();

            string path_LINCINPX = ConfigurationManager.AppSettings["LINCINPX_path"].ToString();
            string template_LINCINPX = ConfigurationManager.AppSettings["LINCINPX_template"].ToString();
            string destinationfile_LINCINPX = lincoln_Outputpath + "Lincoln_Uncombined_Transactions_" + DateTime.Now.ToString("yyyy") + ".xls";

            string path_LINCRPTX = ConfigurationManager.AppSettings["LINCRPTX_path"].ToString();
            string template_LINCRPTX = ConfigurationManager.AppSettings["LINCRPTX_template"].ToString();
            string destinationfile_LINCRPTX = lincoln_Outputpath + "Lincoln_Combined_Transactions_" + DateTime.Now.ToString("yyyy") + ".xls";

            string path_WMPNXCEL = ConfigurationManager.AppSettings["WMPNXCEL_path"].ToString();
            string template_WMPNXCEL = ConfigurationManager.AppSettings["WMPNXCEL_template"].ToString();
            string destinationfile_WMPNXCEL = william_penn_Outputpath + "WP_Combined_Transactions_" + DateTime.Now.ToString("yyyy") + ".xls";

            string path_WMPNXUNC = ConfigurationManager.AppSettings["WMPNXUNC_path"].ToString();
            string template_WMPNXUNC = ConfigurationManager.AppSettings["WMPNXUNC_template"].ToString();
            string destinationfile_WMPNXUNC = william_penn_Outputpath + "WP_Uncombined_Transactions_" + DateTime.Now.ToString("yyyy") + ".xls";

            string path_CLVNXL = ConfigurationManager.AppSettings["CLVNXL_path"].ToString();
            string template_CLVNXL = ConfigurationManager.AppSettings["CLVNXL_template"].ToString();
            string destinationfile_CLVNXL = Vendor_Outputpath + "CLA_Vendor_" + DateTime.Now.ToString("yyyy") + "_1099I" + ".xls";

            string path_NYVNXL = ConfigurationManager.AppSettings["NYVNXL_path"].ToString();
            string template_NYVNXL = ConfigurationManager.AppSettings["NYVNXL_template"].ToString();
            string destinationfile_NYVNXL = Vendor_Outputpath + "First_Unum_" + DateTime.Now.ToString("yyyy") + "_1099I" + ".xls";

            string path_LNVNXL = ConfigurationManager.AppSettings["LNVNXL_path"].ToString();
            string template_LNVNXL = ConfigurationManager.AppSettings["LNVNXL_template"].ToString();
            string destinationfile_LNVNXL = Vendor_Outputpath + "Lincoln_Vendor_" + DateTime.Now.ToString("yyyy") + "_1099I" + ".xls";

            string path_PRVNXL = ConfigurationManager.AppSettings["PRVNXL_path"].ToString();
            string template_PRVNXL = ConfigurationManager.AppSettings["PRVNXL_template"].ToString();
            string destinationfile_PRVNXL = Vendor_Outputpath + "PR_Vendor_" + DateTime.Now.ToString("yyyy") + "_1099I" + ".xls";

            string path_POSNEGST = ConfigurationManager.AppSettings["POSNEGST_path"].ToString();
            string destinationfile_POSNEGST = lincoln_Outputpath + DateTime.Now.ToString("yyyy") + "Lincoln_TaxPort_Stats.docx";

            string path_LINCNONR = ConfigurationManager.AppSettings["LINCNONR_path"].ToString();
            string destinationfile_LINCNONR = lincoln_Outputpath + DateTime.Now.ToString("yyyy") + "_Lincoln_Non - Reportable_TINs.docx";

            string path_WMPNTOTS = ConfigurationManager.AppSettings["WMPNTOTS_path"].ToString();
            string destinationfile_WMPNTOTS = william_penn_Outputpath + DateTime.Now.ToString("yyyy") + "_WP_Totals.docx";

            string path_CLINAUDT = ConfigurationManager.AppSettings["CLINAUDT_path"].ToString();
            string destinationfile_CLINAUDT = Vendor_Outputpath + "CLA_NameAddrChgs_1099_" + DateTime.Now.ToString("yyyy") + ".docx";

            string path_NYINAUDT = ConfigurationManager.AppSettings["NYINAUDT_path"].ToString();
            string destinationfile_NYINAUDT = Vendor_Outputpath + "FU_NameAddrChgs_1099_" + DateTime.Now.ToString("yyyy") + ".docx";

            string path_PRINAUDT = ConfigurationManager.AppSettings["PRINAUDT_path"].ToString();
            string destinationfile_PRINAUDT = Vendor_Outputpath + "PR_NameAddrChgs_1099_" + DateTime.Now.ToString("yyyy") + ".docx";

            string htmlFile = ConfigurationManager.AppSettings["HTMLfile"].ToString();
            string mail_From = ConfigurationManager.AppSettings["Mail_From"].ToString();
            string mail_To_Lincoln = ConfigurationManager.AppSettings["Lincoln_Mail_To"].ToString();
            string mail_CC_Lincoln = ConfigurationManager.AppSettings["Lincoln_Mail_CC"].ToString();
            string mail_To_WP = ConfigurationManager.AppSettings["WP_Mail_To"].ToString();
            string mail_CC_WP = ConfigurationManager.AppSettings["WP_Mail_CC"].ToString();
            string mail_To_Vendor = ConfigurationManager.AppSettings["Vendor_Mail_To"].ToString();
            string mail_CC_Vendor = ConfigurationManager.AppSettings["Vendor_Mail_CC"].ToString();
            string logPath = ConfigurationManager.AppSettings["Logs"].ToString();
            string logFilename = logPath + "Logs -" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
            string zipFilepath = ConfigurationManager.AppSettings["zipfilepath"].ToString();
            string zipfile_Lincon = zipFilepath + "Lincoln 1099 files" + DateTime.Now.ToString("yyyy") + ".zip";
            string zipfile_WP = zipFilepath + "William Penn 1099 files " + DateTime.Now.ToString("yyyy") + ".zip";
            string zipfile_Vendor = zipFilepath + "1099 Vendor files and Name and Address Changes files" + DateTime.Now.ToString("yyyy") + ".zip";
            try
            {
                Dataextract_TLNCSIGN(path_LINCDRPT, template_TLNCSIGN, destinationfile_TLNCSIGN, logFilename);

                Dataextract_PLNCSIN2(path_ARGAMLNL, template_PLNCSIN2, destinationfile_PLNCSIN2, logFilename);

                ConverttoExcel_LINCINPX_LINCRPTX(template_LINCINPX, path_LINCINPX, destinationfile_LINCINPX, template_LINCRPTX, path_LINCRPTX, destinationfile_LINCRPTX,
                                                    template_WMPNXCEL, path_WMPNXCEL, destinationfile_WMPNXCEL, template_WMPNXUNC, path_WMPNXUNC, destinationfile_WMPNXUNC,
                                                    template_CLVNXL, path_CLVNXL, destinationfile_CLVNXL, template_NYVNXL, path_NYVNXL, destinationfile_NYVNXL,
                                                    template_LNVNXL, path_LNVNXL, destinationfile_LNVNXL, template_PRVNXL, path_PRVNXL, destinationfile_PRVNXL, logFilename);

                ConverttoDocx_LINCNONR_POSNEGST(path_LINCNONR, destinationfile_LINCNONR, path_POSNEGST, destinationfile_POSNEGST,
                                                     path_WMPNTOTS, destinationfile_WMPNTOTS, path_CLINAUDT, destinationfile_CLINAUDT,
                                                     path_NYINAUDT, destinationfile_NYINAUDT, path_PRINAUDT, destinationfile_PRINAUDT, logFilename);

                SendMail(mail_From, lincoln_Outputpath, mail_To_Lincoln, mail_CC_Lincoln, william_penn_Outputpath, mail_To_WP, mail_CC_WP,
                             Vendor_Outputpath, mail_To_Vendor, mail_CC_Vendor, htmlFile, logFilename, zipfile_Lincon, zipfile_WP, zipfile_Vendor);

                MoveInput_OutputfilesToArchive(inputPath, inputArchive_path, destinationFilepath, lincoln_Outputpath,
                                                     william_penn_Outputpath, Vendor_Outputpath, outputArchive_path, logFilename);

            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        /// Extract value of "TOTAL TINS PROCESSED:","TOTAL INTEREST EARNINGS:" from the LINCDRPT file and replace the mark in the text file template with the extracted values.
        /// if no values are available for "TOTAL TINS PROCESSED:","TOTAL INTEREST EARNINGS:",then replace teh mark with 0 in the text template and save it in the destination folder
        /// </summary>
        /// <param name="path">Path of the LINCDRPT text file.</param>
        /// <param name="sourceFile">Name of the TLNCSIGN tempalte.</param>
        /// <param name="destinationFile">Name of the output file </param>      
        /// <param name="logFilename">Name of the logfile.</param>

        private static void Dataextract_TLNCSIGN(string path, string sourceFile, string destinationFile, string logFilename)
        {

            try
            {
                var file = File.ReadAllLines(path);
                WriteLog(logFilename, "file has been read successfully" + DateTime.Now.ToString());
                string searchTins = "TOTAL TINS PROCESSED:";
                string searchAmount = "TOTAL INTEREST EARNINGS:";

                if (File.Exists(destinationFile))
                    File.Delete(destinationFile);
                File.Copy(sourceFile, destinationFile);
                foreach (var line in file)
                {
                    if (line.Contains(searchTins))
                    {
                        string output = line.Split(':').Last();
                        string res_Count = output.Trim();
                        WriteLog(logFilename, output);
                        Console.WriteLine(output);
                        Console.WriteLine("File copied successfully");
                        string readData = File.ReadAllText(destinationFile);

                        if (res_Count.Length > 0)
                        {
                            string readCount = readData.Replace("#count".Trim(), res_Count);
                            File.WriteAllText(destinationFile, readCount);
                            WriteLog(logFilename, "#count has been written successfully in the destination file" + DateTime.Now.ToString());
                        }
                        else
                        {
                            string readcount = readData.Replace("#count".Trim(), "0");
                            File.WriteAllText(destinationFile, readcount);
                            WriteLog(logFilename, "#amount is not available.so zero updated in that field" + DateTime.Now.ToString());
                        }
                    }

                    if (line.Contains(searchAmount))
                    {
                        string output_amount = line.Split(':').Last();
                        string res_Amount = output_amount.Trim();
                        Console.WriteLine(output_amount);
                        string readData = File.ReadAllText(destinationFile);
                        if (res_Amount.Length > 0)
                        {
                            string readAmount = readData.Replace("#amount".Trim(), res_Amount);
                            readAmount = readAmount.Trim();
                            File.WriteAllText(destinationFile, readAmount);
                            WriteLog(logFilename, "#amount has been written successfully in the destination file" + DateTime.Now.ToString());
                        }
                        else
                        {
                            string readAmount = readData.Replace("#amount".Trim(), "0.00");
                            readAmount = readAmount.Trim();
                            File.WriteAllText(destinationFile, readAmount);
                            WriteLog(logFilename, "#amount is not available.so zero updated in that field" + DateTime.Now.ToString());
                        }

                    }

                    string readYeardata = File.ReadAllText(destinationFile);
                    string readYear = readYeardata.Replace("#year", DateTime.Now.ToString("yyyy"));
                    File.WriteAllText(destinationFile, readYear);
                    WriteLog(logFilename, "#year has been written successfully in the destination file" + DateTime.Now.ToString());

                    string readDatedata = File.ReadAllText(destinationFile);
                    string readDate = readDatedata.Replace("#date", DateTime.Now.ToString("yyyy/MM/dd"));
                    File.WriteAllText(destinationFile, readDate);
                    WriteLog(logFilename, "#date has been written successfully in the destination file" + DateTime.Now.ToString());
                }

            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
            }
        }

        /// <summary>
        /// Extract value of gross distribution,federal tax,record count,premiumpaid,taxable amount from the ARGAMLNL file and replace the mark in the text file template with the extracted values.
        /// if no values are available,then replace teh mark with 0 in the text template and save it in the destination folder.
        /// </summary>
        /// <param name="path">Path of the ARGAMLNL text file.</param>
        /// <param name="sourceFile">Name of the PLNCSIN2 tempalte.</param>
        /// <param name="destinationFile">Name of the output file </param>      
        /// <param name="logFilename">Name of the logfile.</param>
        private static void Dataextract_PLNCSIN2(string path, string sourceFile, string destinationFile, string logFilename)
        {

            try
            {
                var file = File.ReadAllLines(path);
                WriteLog(logFilename, "file has been read successfully" + DateTime.Now.ToString());
                string grossDistribution1 = "DISTRIBUTION1:";
                string federalTax1 = "WITHELD1:";
                string recordCount1 = "RECORDS1:";
                string premiumPaid1 = "PAID1:";
                string taxableAmnt1 = "AMOUNT:";
                string grossDistribution2 = "DISTRIBUTION2:";
                string federalTax2 = "WITHELD2:";
                string recordCount2 = "RECORDS2:";
                string premiumPaid2 = "PAID2:";

                if (File.Exists(destinationFile))
                    File.Delete(destinationFile);
                File.Copy(sourceFile, destinationFile);
                foreach (var line in file)
                {

                    var splitValues = line.Split(new char[] { '|' });

                    foreach (var value in splitValues)
                    {
                        if (value.Contains(grossDistribution1))
                        {
                            var gross1 = value.Split(':').Last();
                            string res_Gross1 = gross1.Trim();
                            Console.WriteLine(res_Gross1);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_Gross1.Length > 0)
                            {
                                string replace_Gross1 = readTemplatedata.Replace("#gross1".Trim(), res_Gross1);
                                File.WriteAllText(destinationFile, replace_Gross1);
                                WriteLog(logFilename, "#gross1 has been written successfully in the destination file" + DateTime.Now.ToString());
                            }
                            else
                            {
                                string replace_Gross1 = readTemplatedata.Replace("#gross1".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_Gross1);
                                WriteLog(logFilename, "#gross1 is not available.so zero updated in that field" + DateTime.Now.ToString());
                            }

                        }

                        if (value.Contains(grossDistribution2))
                        {
                            var gross2 = value.Split(':').Last();
                            string res_Gross2 = gross2.Trim();
                            Console.WriteLine(res_Gross2);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_Gross2.Length > 0)
                            {
                                string replace_Gross2 = readTemplatedata.Replace("#gross2".Trim(), res_Gross2);
                                File.WriteAllText(destinationFile, replace_Gross2);
                                WriteLog(logFilename, "#gross2 has been written successfully in the destination file" + DateTime.Now.ToString());
                            }
                            else
                            {
                                string replace_Gross2 = readTemplatedata.Replace("#gross2".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_Gross2);
                                WriteLog(logFilename, "#gross2 is not available.so zero updated in that field" + DateTime.Now.ToString());

                            }

                        }

                        if (value.Contains(recordCount1))
                        {
                            var recrdCnt1 = value.Split(':').Last();
                            string res_recrdCnt1 = recrdCnt1.Trim();
                            Console.WriteLine(res_recrdCnt1);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_recrdCnt1.Length > 0)
                            {
                                string replace_recrdcnt1 = readTemplatedata.Replace("#recordcnt1".Trim(), res_recrdCnt1);
                                File.WriteAllText(destinationFile, replace_recrdcnt1);
                                WriteLog(logFilename, "#recordcnt1 has been written successfully in the destination file" + DateTime.Now.ToString());
                            }
                            else
                            {
                                string replace_recrdcnt1 = readTemplatedata.Replace("#recordcnt1".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_recrdcnt1);
                                WriteLog(logFilename, "#recordcnt1 is not available.so zero updated in that field" + DateTime.Now.ToString());

                            }

                        }

                        if (value.Contains(recordCount2))
                        {
                            var recrdCnt2 = value.Split(':').Last();
                            string res_recrdCnt2 = recrdCnt2.Trim();
                            Console.WriteLine(res_recrdCnt2);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_recrdCnt2.Length > 0)
                            {
                                string replace_Recrdcnt2 = readTemplatedata.Replace("#recordcnt2".Trim(), res_recrdCnt2);
                                File.WriteAllText(destinationFile, replace_Recrdcnt2);
                                WriteLog(logFilename, "#recordcnt2 has been written successfully in the destination file" + DateTime.Now.ToString());

                            }
                            else
                            {
                                string replace_Recrdcnt2 = readTemplatedata.Replace("#recordcnt2".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_Recrdcnt2);
                                WriteLog(logFilename, "#recordcnt2 is not available.so zero updated in that field" + DateTime.Now.ToString());
                            }

                        }

                        if (value.Contains(federalTax1))
                        {
                            var federal1 = value.Split(':').Last();
                            string res_Federal1 = federal1.Trim();
                            Console.WriteLine(res_Federal1);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_Federal1.Length > 0)
                            {
                                string replace_Federal1 = readTemplatedata.Replace("#federaltax1".Trim(), res_Federal1);
                                File.WriteAllText(destinationFile, replace_Federal1);
                                WriteLog(logFilename, "#federaltax1 has been written successfully in the destination file" + DateTime.Now.ToString());
                            }
                            else
                            {
                                string replace_Federal1 = readTemplatedata.Replace("#federaltax1".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_Federal1);
                                WriteLog(logFilename, "#federaltax1 is not available.so zero updated in that field" + DateTime.Now.ToString());
                            }

                        }

                        if (value.Contains(federalTax2))
                        {
                            var federal2 = value.Split(':').Last();
                            string res_Federal2 = federal2.Trim();
                            Console.WriteLine(res_Federal2);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_Federal2.Length > 0)
                            {
                                string replace_Federal2 = readTemplatedata.Replace("#federaltax2".Trim(), res_Federal2);
                                File.WriteAllText(destinationFile, replace_Federal2);
                                WriteLog(logFilename, "#federaltax2 has been written successfully in the destination file" + DateTime.Now.ToString());
                            }
                            else
                            {
                                string replace_Federal2 = readTemplatedata.Replace("#federaltax2".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_Federal2);
                                WriteLog(logFilename, "#federaltax2 is not available.so zero updated in that field" + DateTime.Now.ToString());
                            }

                        }

                        if (value.Contains(premiumPaid2))
                        {
                            var premium2 = value.Split(':').Last();
                            string res_Premium2 = premium2.Trim();
                            Console.WriteLine(res_Premium2);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_Premium2.Length > 0)
                            {
                                string replace_Premium2 = readTemplatedata.Replace("#premium2".Trim(), res_Premium2);
                                File.WriteAllText(destinationFile, replace_Premium2);
                                WriteLog(logFilename, "#premium2 has been written successfully in the destination file" + DateTime.Now.ToString());
                            }
                            else
                            {
                                string replace_Premium2 = readTemplatedata.Replace("#premium2".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_Premium2);
                                WriteLog(logFilename, "#premium2 is not available.so zero updated in that field" + DateTime.Now.ToString());
                            }

                        }
                        if (value.Contains(premiumPaid1))
                        {
                            var premium1 = value.Split(':').Last();
                            string res_Premium1 = premium1.Trim();
                            Console.WriteLine(res_Premium1);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_Premium1.Length > 0)
                            {
                                string replace_Premium1 = readTemplatedata.Replace("#premium1".Trim(), res_Premium1);
                                File.WriteAllText(destinationFile, replace_Premium1);
                                WriteLog(logFilename, "#premium1 has been written successfully in the destination file" + DateTime.Now.ToString());
                            }
                            else
                            {
                                string replace_Premium1 = readTemplatedata.Replace("#premium1".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_Premium1);
                                WriteLog(logFilename, "#premium1 is not available.so zero updated in that field" + DateTime.Now.ToString());
                            }

                        }
                        if (value.Contains(taxableAmnt1))
                        {
                            var taxAmnt1 = value.Split(':').Last();
                            string res_taxAmnt1 = taxAmnt1.Trim();
                            Console.WriteLine(res_taxAmnt1);
                            string readTemplatedata = File.ReadAllText(destinationFile);
                            if (res_taxAmnt1.Length > 0)
                            {
                                string replace_taxamnt1 = readTemplatedata.Replace("#taxableAmnt1".Trim(), res_taxAmnt1);
                                File.WriteAllText(destinationFile, replace_taxamnt1);
                                WriteLog(logFilename, "#taxableAmnt1 has been written successfully in the destination file" + DateTime.Now.ToString());
                            }
                            else
                            {
                                string replace_taxAmnt1 = readTemplatedata.Replace("#taxableAmnt1".Trim(), "0");
                                File.WriteAllText(destinationFile, replace_taxAmnt1);
                                WriteLog(logFilename, "#taxableAmnt1 is not available.so zero updated in that field" + DateTime.Now.ToString());
                            }

                        }

                    }
                    string readTemplatedata_date = File.ReadAllText(destinationFile);
                    string replace_Date = readTemplatedata_date.Replace("#date".Trim(), DateTime.Now.ToString("yyyy/MM/dd"));
                    File.WriteAllText(destinationFile, replace_Date);
                    string readTemplatedata_year = File.ReadAllText(destinationFile);
                    string replace_Year = readTemplatedata_year.Replace("#year".Trim(), DateTime.Now.ToString("yyyy"));
                    File.WriteAllText(destinationFile, replace_Year);
                    WriteLog(logFilename, "#year has been written successfully in the destination file" + DateTime.Now.ToString());
                }
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
            }
        }

        /// <summary>
        /// Copy the data from the text file to the excel template and save it in the destination folder
        /// </summary>
        /// <param name="template_LINCINPX">Path of the template  file.</param>
        /// <param name="template_LINCRPTX">Path of the template  file.</param>
        /// <param name="template_WMPNXCEL">Path of the template  file.</param>
        /// <param name = "template_WMPNXUNC" > Path of the template  file.</param>
        /// <param name="template_CLVNXL">Path of the template  file</param>
        /// <param name="template_NYVNXL">Path of the template  file</param>
        /// <param name="template_LNVNXL">Path of the template  file</param>
        /// <param name="template_PRVNXL">Path of the template  file.</param>
        /// <param name="source_LINCINPX">Name of the source file</param>
        /// <param name="source_LINCRPTX">Name of the source file</param>
        /// <param name="source_WMPNXCEL">Name of the source file</param>
        /// <param name = "source_WMPNXUNC" >Name of the source file</param>
        /// <param name="source_CLVNXL">Name of the source file</param>
        /// <param name="source_NYVNXL">Name of the source file</param>
        /// <param name="source_LNVNXL">Name of the source file</param>
        /// <param name="source_PRVNXL">Name of the source file</param>
        /// <param name="destinaiton_LINCINPX">Name of the destination file</param>
        /// <param name="destinaiton_LINCRPTX">Name of the destination file</param>
        /// <param name="destinaiton_WMPNXCEL">Name of the destination file.</param>
        /// <param name = "destinaiton_WMPNXUNC" >Name of the destination file.</param>
        /// <param name="destinaiton_CLVNXL">Name of the destination file</param>
        /// <param name="destinaiton_NYVNXL">Name of the destination file</param>
        /// <param name="destinaiton_LNVNXL">Name of the destination file</param>
        /// <param name="destinaiton_PRVNXL">Name of the destination file</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void ConverttoExcel_LINCINPX_LINCRPTX(string template_LINCINPX, string source_LINCINPX, string destination_LINCINPX, string template_LINCRPTX, string source_LINCRPTX, string destination_LINCRPTX,
                                                                  string template_WMPNXCEL, string source_WMPNXCEL, string destination_WMPNXCEL, string template_WMPNXUNC, string source_WMPNXUNC, string destination_WMPNXUNC,
                                                                  string template_CLVNXL, string source_CLVNXL, string destination_CLVNXL, string template_NYVNXL, string source_NYVNXL, string destination_NYVNXL,
                                                                  string template_LNVNXL, string source_LNVNXL, string destination_LNVNXL, string template_PRVNXL, string source_PRVNXL, string destination_PRVNXL, string logFilename)

        {
            try
            {
                excel.Application excellApp = new excel.Application();
                object misValue = System.Reflection.Missing.Value;
                ///excellApp.Visible = true;

                var wb_LINCINPX = excellApp.Workbooks.Add(template_LINCINPX);
                var ws_LINCINPX = (excel.Worksheet)wb_LINCINPX.Worksheets.Item[1];
                excellApp.Workbooks.OpenText(source_LINCINPX, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                             misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_Text_LINCINPX = excellApp.ActiveWorkbook;
                var ws_Text_LINCINPX = (excel.Worksheet)wb_Text_LINCINPX.Worksheets.Item[1];
                ws_Text_LINCINPX.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_LINCINPX.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text_LINCINPX.get_Range("A1").Copy();
                wb_Text_LINCINPX.Close(SaveChanges: false);

                excel.Worksheet ws_Formula = (excel.Worksheet)wb_LINCINPX.Worksheets.Item[2];
                var usedrow_LINCINPX = ws_LINCINPX.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                                       excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                ws_Formula.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from = ws_Formula.get_Range("A1:A" + usedrow_LINCINPX);
                excel.Range to = ws_LINCINPX.get_Range("H1:H" + usedrow_LINCINPX);
                from.Copy(to);

                ws_Formula.get_Range("B1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula.Cells[1, 2].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from1 = ws_Formula.get_Range("B1:B" + usedrow_LINCINPX);
                excel.Range to1 = ws_LINCINPX.get_Range("K1:K" + usedrow_LINCINPX);
                from1.Copy(to1);

                ws_LINCINPX.get_Range("L1").EntireColumn.Delete();
                ws_LINCINPX.Columns["A:Z"].AutoFit();
                ws_Formula.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_LINCINPX.SaveAs(destination_LINCINPX, excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
               excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_LINCINPX.Close();

                //////    LINCRPTX excel conversion 
                var wb_LINCRPTX = excellApp.Workbooks.Add(template_LINCRPTX);
                var ws_LINCRPTX = (excel.Worksheet)wb_LINCRPTX.Worksheets.Item[1];

                excellApp.Workbooks.OpenText(source_LINCRPTX, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                            misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_Text_LINCRPTX = excellApp.ActiveWorkbook;
                var ws_Text_LINCRPTX = (excel.Worksheet)wb_Text_LINCRPTX.Worksheets.Item[1];
                ws_Text_LINCRPTX.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_LINCRPTX.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text_LINCRPTX.get_Range("A1").Copy();
                wb_Text_LINCRPTX.Close(SaveChanges: false);

                excel.Worksheet ws_Formula_LINCRPTX = (excel.Worksheet)wb_LINCRPTX.Worksheets.Item[2];
                var usedrow_LINCRPTX = ws_LINCRPTX.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                                     excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                ws_Formula_LINCRPTX.get_Range("B1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula_LINCRPTX.Cells[1, 2].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from2 = ws_Formula_LINCRPTX.get_Range("B1:B" + usedrow_LINCRPTX);
                excel.Range to2 = ws_LINCRPTX.get_Range("K1:K" + usedrow_LINCRPTX);
                from2.Copy(to2);

                ws_LINCRPTX.get_Range("L1").EntireColumn.Delete();
                ws_Formula_LINCRPTX.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula_LINCRPTX.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from_LINCRPTX = ws_Formula_LINCRPTX.get_Range("A1:A" + usedrow_LINCRPTX);
                excel.Range to_LINCRPTX = ws_LINCRPTX.get_Range("H1:H" + usedrow_LINCRPTX);
                from_LINCRPTX.Copy(to_LINCRPTX);

                ws_LINCRPTX.Columns["A:Z"].AutoFit();
                ws_Formula_LINCRPTX.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_LINCRPTX.SaveAs(destination_LINCRPTX, excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
               excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_LINCRPTX.Close();

                //////   WMPNXCEL excel conversion 
                var wb_WMPNXCEL = excellApp.Workbooks.Add(template_WMPNXCEL);
                var ws_WMPNXCEL = (excel.Worksheet)wb_WMPNXCEL.Worksheets.Item[1];

                excellApp.Workbooks.OpenText(source_WMPNXCEL, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                             misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_Text_WMPNXCEL = excellApp.ActiveWorkbook;
                var ws_Text_WMPNXCEL = (excel.Worksheet)wb_Text_WMPNXCEL.Worksheets.Item[1];
                ws_Text_WMPNXCEL.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_WMPNXCEL.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text_WMPNXCEL.get_Range("A1").Copy();
                wb_Text_WMPNXCEL.Close(SaveChanges: false);

                excel.Worksheet ws_Formula_WMPNXCEL = (excel.Worksheet)wb_WMPNXCEL.Worksheets.Item[2];
                var usedrow_WMPNXCEL = ws_WMPNXCEL.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                                    excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                ws_Formula_WMPNXCEL.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula_WMPNXCEL.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from_WMPNXCEL = ws_Formula_WMPNXCEL.get_Range("A1:A" + usedrow_WMPNXCEL);
                excel.Range to_WMPNXCEL = ws_WMPNXCEL.get_Range("H1:H" + usedrow_WMPNXCEL);
                from_WMPNXCEL.Copy(to_WMPNXCEL);

                ws_WMPNXCEL.Columns["A:Z"].AutoFit();
                ws_Formula_WMPNXCEL.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_WMPNXCEL.SaveAs(destination_WMPNXCEL, excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
                excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_WMPNXCEL.Close();

                ////   WMPNXUNC excel conversion 
                var wb_WMPNXUNC = excellApp.Workbooks.Add(template_WMPNXUNC);
                var ws_WMPNXUNC = (excel.Worksheet)wb_WMPNXUNC.Worksheets.Item[1];

                excellApp.Workbooks.OpenText(source_WMPNXUNC, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                                  misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_Text_WMPNXUNC = excellApp.ActiveWorkbook;
                var ws_Text_WMPNXUNC = (excel.Worksheet)wb_Text_WMPNXUNC.Worksheets.Item[1];
                ws_Text_WMPNXUNC.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_WMPNXUNC.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text_WMPNXUNC.get_Range("A1").Copy();
                wb_Text_WMPNXUNC.Close(SaveChanges: false);

                excel.Worksheet ws_Formula_WMPNXUNC = (excel.Worksheet)wb_WMPNXUNC.Worksheets.Item[2];
                var usedrow_WMPNXUNC = ws_WMPNXUNC.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                                   excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                ws_Formula_WMPNXUNC.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula_WMPNXUNC.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from_WMPNXUNC = ws_Formula_WMPNXUNC.get_Range("A1:A" + usedrow_WMPNXUNC);
                excel.Range to_WMPNXUNC = ws_WMPNXUNC.get_Range("H1:H" + usedrow_WMPNXUNC);
                from_WMPNXUNC.Copy(to_WMPNXUNC);

                ws_WMPNXUNC.Columns["A:Z"].AutoFit();
                ws_Formula_WMPNXUNC.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_WMPNXUNC.SaveAs(destination_WMPNXUNC, excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
                excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_WMPNXUNC.Close();

                //   CLVNXL excel conversion 
                var wb_CLVNXL = excellApp.Workbooks.Add(template_CLVNXL);
                var ws_CLVNXL = (excel.Worksheet)wb_CLVNXL.Worksheets.Item[1];

                excellApp.Workbooks.OpenText(source_CLVNXL, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                               misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_Text_CLVNXL = excellApp.ActiveWorkbook;
                var ws_Text_CLVNXL = (excel.Worksheet)wb_Text_CLVNXL.Worksheets.Item[1];
                ws_Text_CLVNXL.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_CLVNXL.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text_CLVNXL.get_Range("A1").Copy();
                wb_Text_CLVNXL.Close(SaveChanges: false);

                excel.Worksheet ws_Formula_CLVNXL = (excel.Worksheet)wb_CLVNXL.Worksheets.Item[2];
                var usedrow_CLVNXL = ws_CLVNXL.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                                 excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                ws_Formula_CLVNXL.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula_CLVNXL.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from5 = ws_Formula_CLVNXL.get_Range("A1:A" + usedrow_CLVNXL);
                excel.Range to5 = ws_CLVNXL.get_Range("G1:G" + usedrow_CLVNXL);
                from5.Copy(to5);

                ws_CLVNXL.Columns["A:Z"].AutoFit();
                ws_Formula_CLVNXL.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_CLVNXL.SaveAs(destination_CLVNXL, excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
                excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_CLVNXL.Close();

                //   NYVNXL excel conversion 
                var wb_NYVNXL = excellApp.Workbooks.Add(template_NYVNXL);
                var ws_NYVNXL = (excel.Worksheet)wb_NYVNXL.Worksheets.Item[1];

                excellApp.Workbooks.OpenText(source_NYVNXL, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                     misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_Text_NYVNXL = excellApp.ActiveWorkbook;
                var ws_Text_NYVNXL = (excel.Worksheet)wb_Text_NYVNXL.Worksheets.Item[1];
                ws_Text_NYVNXL.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_NYVNXL.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text_NYVNXL.get_Range("A1").Copy();
                wb_Text_NYVNXL.Close(SaveChanges: false);

                excel.Worksheet ws_Formula_NYVNXL = (excel.Worksheet)wb_NYVNXL.Worksheets.Item[2];
                var usedrow_NYVNXL = ws_NYVNXL.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                               excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                ws_Formula_NYVNXL.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula_NYVNXL.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from6 = ws_Formula_NYVNXL.get_Range("A1:A" + usedrow_NYVNXL);
                excel.Range to6 = ws_NYVNXL.get_Range("G1:G" + usedrow_NYVNXL);
                from6.Copy(to6);

                ws_NYVNXL.Columns["A:Z"].AutoFit();
                ws_Formula_NYVNXL.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_NYVNXL.SaveAs(destination_NYVNXL, excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
                excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_NYVNXL.Close();

                //   LNVNXL excel conversion 
                var wb_LNVNXL = excellApp.Workbooks.Add(template_LNVNXL);
                var ws_LNVNXL = (excel.Worksheet)wb_LNVNXL.Worksheets.Item[1];

                excellApp.Workbooks.OpenText(source_LNVNXL, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                         misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_Text_LNVNXL = excellApp.ActiveWorkbook;
                var ws_Text_LNVNXL = (excel.Worksheet)wb_Text_LNVNXL.Worksheets.Item[1];
                ws_Text_LNVNXL.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_LNVNXL.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text_LNVNXL.get_Range("A1").Copy();
                wb_Text_LNVNXL.Close(SaveChanges: false);

                excel.Worksheet ws_Formula_LNVNXL = (excel.Worksheet)wb_LNVNXL.Worksheets.Item[2];
                var usedrow_LNVNXL = ws_LNVNXL.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                              excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                ws_Formula_LNVNXL.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula_LNVNXL.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from7 = ws_Formula_LNVNXL.get_Range("A1:A" + usedrow_LNVNXL);
                excel.Range to7 = ws_LNVNXL.get_Range("G1:G" + usedrow_LNVNXL);
                from7.Copy(to7);

                ws_LNVNXL.Columns["A:Z"].AutoFit();
                ws_Formula_LNVNXL.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_LNVNXL.SaveAs(destination_LNVNXL, excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
                excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_LNVNXL.Close();

                //   PRVNXL excel conversion 
                var wb_PRVNXL = excellApp.Workbooks.Add(template_PRVNXL);
                var ws_PRVNXL = (excel.Worksheet)wb_PRVNXL.Worksheets.Item[1];

                excellApp.Workbooks.OpenText(source_PRVNXL, misValue, 1, excel.XlTextParsingType.xlDelimited, excel.XlTextQualifier.xlTextQualifierNone,
                        misValue, misValue, misValue, false, misValue, true, "~", misValue, misValue, misValue, misValue, misValue, misValue);

                var wb_Text_PRVNXL = excellApp.ActiveWorkbook;
                var ws_Text_PRVNXL = (excel.Worksheet)wb_Text_PRVNXL.Worksheets.Item[1];
                ws_Text_PRVNXL.UsedRange.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_PRVNXL.get_Range("A1").PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                ws_Text_PRVNXL.get_Range("A1").Copy();
                wb_Text_PRVNXL.Close(SaveChanges: false);

                excel.Worksheet ws_Formula_PRVNXL = (excel.Worksheet)wb_PRVNXL.Worksheets.Item[2];
                var usedrow_PRVNXL = ws_PRVNXL.Cells.Find("*", System.Reflection.Missing.Value, System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                                             excel.XlSearchOrder.xlByRows, excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                ws_Formula_PRVNXL.get_Range("A1").EntireColumn.SpecialCells(excel.XlCellType.xlCellTypeVisible, Type.Missing).Copy();
                ws_Formula_PRVNXL.Cells[1, 1].PasteSpecial(excel.XlPasteType.xlPasteValues, excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                excel.Range from8 = ws_Formula_PRVNXL.get_Range("A1:A" + usedrow_PRVNXL);
                excel.Range to8 = ws_PRVNXL.get_Range("G1:G" + usedrow_PRVNXL);
                from8.Copy(to8);

                ws_PRVNXL.Columns["A:Z"].AutoFit();
                ws_Formula_PRVNXL.Visible = Microsoft.Office.Interop.Excel.XlSheetVisibility.xlSheetHidden;
                wb_PRVNXL.SaveAs(destination_PRVNXL, excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
                excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                wb_PRVNXL.Close();

                excellApp.Quit();

            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
            }
        }

        /// <summary>
        /// Convert the text files to docx format.Change the page orientation to landscape mode and page size to legal
        /// </summary>
        /// <param name="source_LINCNONR">Name of the source file</param>
        /// <param name="source_POSNEGST">Name of the source file</param>
        /// <param name="source_WMPNTOTS">Name of the source file</param>
        /// <param name="source_CLINAUDT">Name of the source file</param>
        /// <param name="source_NYINAUDT">Name of the source file</param>
        /// <param name="source_PRINAUDT">Name of the source file</param>
        /// <param name="destination_LINCNONR">Name of the destination file</param>
        /// <param name="destination_POSNEGST">Name of the destination file</param>
        /// <param name="destination_WMPNTOTS">Name of the destination file</param>
        /// <param name="destination_CLINAUDT">Name of the destination file</param>
        /// <param name="destination_NYINAUDT">Name of the destination file</param>
        /// <param name="destination_PRINAUDT">Name of the destination file</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void ConverttoDocx_LINCNONR_POSNEGST(string source_LINCNONR, string destination_LINCNONR, string source_POSNEGST, string destination_POSNEGST,
                                                             string source_WMPNTOTS, string destination_WMPNTOTS, string source_CLINAUDT, string destination_CLINAUDT,
                                                              string source_NYINAUDT, string destination_NYINAUDT, string source_PRINAUDT, string destination_PRINAUDT, string logFilename)
        {
            try
            {
                Microsoft.Office.Interop.Word.Application wordapp = new Microsoft.Office.Interop.Word.Application();
                object docmisValue = System.Reflection.Missing.Value;
                //wordapp.Visible = true;

                //LINCNONR
                string file_LINCNONR = File.ReadAllText(source_LINCNONR);
                file_LINCNONR = file_LINCNONR.Remove(0, 1);//remove the  junk character in the txt file
                File.WriteAllText(source_LINCNONR, file_LINCNONR);
                Document document_LINCNONR = wordapp.Documents.Open(source_LINCNONR);
                document_LINCNONR.PageSetup.PaperSize = WdPaperSize.wdPaperLegal;
                document_LINCNONR.PageSetup.Orientation = WdOrientation.wdOrientLandscape;

                object sv_LINCNONR = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                document_LINCNONR.SaveAs2(destination_LINCNONR, WdSaveFormat.wdFormatXMLDocument,
                                CompatibilityMode: WdCompatibilityMode.wdWord2010);
                wordapp.ActiveDocument.Close();

                //POSNEGST
                string file_POSNEGST = File.ReadAllText(source_POSNEGST);
                file_POSNEGST = file_POSNEGST.Remove(0, 1);//remove the  junk character in the txt file
                File.WriteAllText(source_POSNEGST, file_POSNEGST);
                Document document_POSNEGST = wordapp.Documents.Open(source_POSNEGST);
                document_POSNEGST.PageSetup.PaperSize = WdPaperSize.wdPaperLegal;
                document_POSNEGST.PageSetup.Orientation = WdOrientation.wdOrientLandscape;

                object sv_POSNEGST = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                document_POSNEGST.SaveAs2(destination_POSNEGST, WdSaveFormat.wdFormatXMLDocument,
                                   CompatibilityMode: WdCompatibilityMode.wdWord2010);
                wordapp.ActiveDocument.Close();

                //WMPNTOTS
                string file_WMPNTOTS = File.ReadAllText(source_WMPNTOTS);
                file_WMPNTOTS = file_WMPNTOTS.Remove(0, 1);//remove the  junk character in the txt file
                File.WriteAllText(source_WMPNTOTS, file_WMPNTOTS);
                Document document_WMPNTOTS = wordapp.Documents.Open(source_WMPNTOTS);
                document_WMPNTOTS.PageSetup.PaperSize = WdPaperSize.wdPaperLegal;
                document_WMPNTOTS.PageSetup.Orientation = WdOrientation.wdOrientLandscape;

                object sv_WMPNTOTS = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                document_WMPNTOTS.SaveAs2(destination_WMPNTOTS, WdSaveFormat.wdFormatXMLDocument,
                                   CompatibilityMode: WdCompatibilityMode.wdWord2010);
                wordapp.ActiveDocument.Close();

                //CLINAUDT
                string file_CLINAUDT = File.ReadAllText(source_CLINAUDT);
                file_CLINAUDT = file_CLINAUDT.Remove(0, 1);//remove the  junk character in the txt file
                File.WriteAllText(source_CLINAUDT, file_CLINAUDT);
                Document document_CLINAUDT = wordapp.Documents.Open(source_CLINAUDT);
                document_CLINAUDT.PageSetup.PaperSize = WdPaperSize.wdPaperLegal;
                document_CLINAUDT.PageSetup.Orientation = WdOrientation.wdOrientLandscape;

                object sv_CLINAUDT = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                document_CLINAUDT.SaveAs2(destination_CLINAUDT, WdSaveFormat.wdFormatXMLDocument,
                                   CompatibilityMode: WdCompatibilityMode.wdWord2010);
                wordapp.ActiveDocument.Close();

                //NYINAUDT
                string file_NYINAUDT = File.ReadAllText(source_NYINAUDT);
                file_NYINAUDT = file_NYINAUDT.Remove(0, 1);//remove the  junk character in the txt file
                File.WriteAllText(source_NYINAUDT, file_NYINAUDT);
                Document document_NYINAUDT = wordapp.Documents.Open(source_NYINAUDT);
                document_NYINAUDT.PageSetup.PaperSize = WdPaperSize.wdPaperLegal;
                document_NYINAUDT.PageSetup.Orientation = WdOrientation.wdOrientLandscape;

                object sv_NYINAUDT = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                document_NYINAUDT.SaveAs2(destination_NYINAUDT, WdSaveFormat.wdFormatXMLDocument,
                                   CompatibilityMode: WdCompatibilityMode.wdWord2010);
                wordapp.ActiveDocument.Close();

                //PRINAUDT
                string file_PRINAUDT = File.ReadAllText(source_PRINAUDT);
                file_PRINAUDT = file_PRINAUDT.Remove(0, 1);//remove the  junk character in the txt file
                File.WriteAllText(source_PRINAUDT, file_PRINAUDT);
                Document document_PRINAUDT = wordapp.Documents.Open(source_PRINAUDT);
                document_PRINAUDT.PageSetup.PaperSize = WdPaperSize.wdPaperLegal;
                document_PRINAUDT.PageSetup.Orientation = WdOrientation.wdOrientLandscape;

                object sv_PRINAUDT = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                document_PRINAUDT.SaveAs2(destination_PRINAUDT, WdSaveFormat.wdFormatXMLDocument,
                                   CompatibilityMode: WdCompatibilityMode.wdWord2010);
                wordapp.ActiveDocument.Close();


                wordapp.Quit();
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
            }
        }


        /// <summary>
        /// Compress the output folder to zipfolder.Attach the zipfolder and send mail
        /// </summary>
        /// <param name="mail_From">Sender of the mail</param>
        /// <param name="output_Lincoln">path of the Lincoln output folder</param>
        /// <param name="mailTo_Lincoln">Contains members in mail To for Lincoln Docs</param>
        /// <param name="mailCC_Lincoln">Contains members in mailCC for Lincoln Docs</param>
        /// <param name="output_WP">path of the WP output folder</param>
        /// <param name="mailTo_WP">Contains members in mail To for WP Docs</param>
        /// <param name="mailCC_WP">Contains members in mailCC for WP docs</param>
        /// <param name="output_Vendor">path of the Vendor output folder</param>
        /// <param name="mailTo_Vendor">Contains members in mail To for Vendor docs</param>
        /// <param name="mailCC_Vendor">Contains members in mailCC for Vendor docs</param>
        /// <param name="logFilename">Name of the logfile.</param>
        private static void SendMail(string mail_From, string output_Lincoln, string mailTo_Lincoln, string mailCC_Lincoln, string output_WP, string mailTo_WP, string mailCC_WP,
                                         string output_Vendor, string mailTo_Vendor, string mailCC_Vendor, string html, string logFilename, string zipfile_Lincoln, string zipfile_WP, string zipfile_Vendor)
        {

            // mail to be send with multiple attachment
            DirectoryInfo op_Lncln = new DirectoryInfo(output_Lincoln);
            FileInfo[] excel_Lncln = op_Lncln.GetFiles("*.xls");
            FileInfo[] doc_Lncln = op_Lncln.GetFiles("*.docx");
            DirectoryInfo WP_op = new DirectoryInfo(output_WP);
            FileInfo[] WP_excel = WP_op.GetFiles("*.xls");
            FileInfo[] WP_Doc = WP_op.GetFiles("*.docx");
            DirectoryInfo Vendor_op = new DirectoryInfo(output_Vendor);
            FileInfo[] Vendor_excel = Vendor_op.GetFiles("*.xls");
            FileInfo[] Vendor_Doc = Vendor_op.GetFiles("*.docx");
            try
            {
                // Lincoln mail
                if (excel_Lncln.Length != 0 || doc_Lncln.Length != 0)
                {
                    using (StreamReader reader = File.OpenText(html)) // Path to your 
                    {                                                         // HTML file
                        ZipFile.CreateFromDirectory(output_Lincoln, zipfile_Lincoln, CompressionLevel.Fastest, true);

                        Console.WriteLine("Lincoln Zip file Create Successfully!! ");
                        System.Net.Mail.MailMessage mail_Lincoln = new System.Net.Mail.MailMessage();
                        mail_Lincoln.Attachments.Add(new Attachment(zipfile_Lincoln));
                        mail_Lincoln.Subject = "Lincoln 1099 files";
                        mail_Lincoln.IsBodyHtml = true;
                        mail_Lincoln.Body = reader.ReadToEnd();
                        mail_Lincoln.From = new MailAddress(mail_From);
                        foreach (var toaddress in mailTo_Lincoln.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_Lincoln.To.Add(toaddress);
                        foreach (var ccaddress in mailCC_Lincoln.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_Lincoln.CC.Add(ccaddress);
                        SmtpClient smtpServer = new SmtpClient("caeemail.unum.com");
                        smtpServer.Send(mail_Lincoln);
                        mail_Lincoln.Attachments.Dispose();
                        Console.WriteLine("Lincoln Mail sent successfully");
                        WriteLog(logFilename, "Lincoln Mail sent successfully" + DateTime.Now.ToString());
                        File.Delete(zipfile_Lincoln);
                        WriteLog(logFilename, "-----------------------------------------------------------------");
                    }
                }
                else
                    WriteLog(logFilename, "File doesnot exists.so Lincoln mail not sent." + DateTime.Now.ToString());
                WriteLog(logFilename, "-----------------------------------------------------------------");
                //WP docs mail
                if (WP_excel.Length != 0 || WP_Doc.Length != 0)
                {
                    using (StreamReader reader = File.OpenText(html)) // Path to your 
                    {                                                         // HTML file

                        ZipFile.CreateFromDirectory(output_WP, zipfile_WP, CompressionLevel.Fastest, true);

                        Console.WriteLine("WP Zip file Create Successfully!! ");
                        System.Net.Mail.MailMessage mail_WP = new System.Net.Mail.MailMessage();
                        mail_WP.Attachments.Add(new Attachment(zipfile_WP));
                        mail_WP.Subject = "William Penn 1099 files ";
                        mail_WP.IsBodyHtml = true;
                        mail_WP.Body = reader.ReadToEnd();
                        mail_WP.From = new MailAddress(mail_From);
                        foreach (var toaddress in mailTo_WP.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_WP.To.Add(toaddress);
                        foreach (var ccaddress in mailCC_WP.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_WP.CC.Add(ccaddress);
                        SmtpClient smtpServer = new SmtpClient("caeemail.unum.com");
                        smtpServer.Send(mail_WP);
                        mail_WP.Attachments.Dispose();
                        Console.WriteLine("WP Mail sent successfully");
                        WriteLog(logFilename, "WP Mail sent successfully" + DateTime.Now.ToString());
                        File.Delete(zipfile_WP);
                        WriteLog(logFilename, "-----------------------------------------------------------------");
                    }
                }
                else
                    WriteLog(logFilename, "File doesnot exists.so WP mail not sent." + DateTime.Now.ToString());
                WriteLog(logFilename, "-----------------------------------------------------------------");

                //Vendor docs mail
                if (Vendor_excel.Length != 0 || Vendor_Doc.Length != 0)
                {
                    using (StreamReader reader = File.OpenText(html)) // Path to your 
                    {                                                         // HTML file

                        ZipFile.CreateFromDirectory(output_Vendor, zipfile_Vendor, CompressionLevel.Fastest, true);
                        Console.WriteLine("Vendor Zip file Create Successfully!! ");
                        System.Net.Mail.MailMessage mail_Vendor = new System.Net.Mail.MailMessage();
                        mail_Vendor.Attachments.Add(new Attachment(zipfile_Vendor));
                        mail_Vendor.Subject = "1099 Vendor files and Name and Address Changes files";
                        mail_Vendor.IsBodyHtml = true;
                        mail_Vendor.Body = reader.ReadToEnd();
                        mail_Vendor.From = new MailAddress(mail_From);
                        foreach (var toaddress in mailTo_Vendor.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_Vendor.To.Add(toaddress);
                        foreach (var ccaddress in mailCC_Vendor.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                            mail_Vendor.CC.Add(ccaddress);
                        SmtpClient smtpServer = new SmtpClient("caeemail.unum.com");
                        smtpServer.Send(mail_Vendor);
                        mail_Vendor.Attachments.Dispose();
                        Console.WriteLine("Vendor Mail sent successfully");
                        WriteLog(logFilename, "Vendor Mail sent successfully" + DateTime.Now.ToString());
                        File.Delete(zipfile_Vendor);
                        WriteLog(logFilename, "-----------------------------------------------------------------");
                    }
                }
                else
                    WriteLog(logFilename, "File doesnot exists.so Vendor mail not sent." + DateTime.Now.ToString());
                WriteLog(logFilename, "-----------------------------------------------------------------");

            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
                WriteLog(logFilename, "-----------------------------------------------------------------");
            }
        }

        /// <summary>
        ///Move the inputfiles to input archieve path
        ///Move the output files to output archieve path
        /// </summary>
        /// <param name="inputFilepath">path of the input folder</param>
        /// <param name="inputArchivepath">path of the input archieve folder</param>
        /// <param name="outputFilepath">Path of the output folder</param>
        /// <param name="outputpath_Lincoln">path of the Lincoln output folder</param>
        /// <param name="outputpath_William_Penn">path of the WP output folder</param>
        /// <param name="outputpath_Vendor">path of the Vendor output folder</param>
        /// <param name="outputArchivepath">Path of the output archieve folder</param>
        /// <param name="logFilename">Name of the logfile.</param>
        static void MoveInput_OutputfilesToArchive(string inputFilepath, string inputArchivepath, string outputFilepath, string outputpath_Lincoln,
                                                        string outputpath_William_Penn, string outputpath_Vendor, string outputArchivepath, string logFilename)
        {
            string[] inputfiles = Directory.GetFiles(inputFilepath);
            string[] oppathfiles = Directory.GetFiles(outputFilepath);
            string[] lnclnfiles = Directory.GetFiles(outputpath_Lincoln);
            string[] wpfiles = Directory.GetFiles(outputpath_William_Penn);
            string[] vendorfiles = Directory.GetFiles(outputpath_Vendor);



            foreach (var oppathfile in oppathfiles)
            {
                File.Move(oppathfile, $"{outputArchivepath}{Path.GetFileNameWithoutExtension(oppathfile)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(oppathfile));
                WriteLog(logFilename, oppathfile + "moved to outputarchievepath");
                Console.WriteLine(oppathfile + "moved to outputarchievepath");
            }
            foreach (var lnclnfile in lnclnfiles)
            {
                File.Move(lnclnfile, $"{outputArchivepath}{Path.GetFileNameWithoutExtension(lnclnfile)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(lnclnfile));
                WriteLog(logFilename, lnclnfile + "moved to outputarchievepath");
                Console.WriteLine(lnclnfile + "moved to outputarchievepath");
            }

            foreach (var Wpfile in wpfiles)
            {
                File.Move(Wpfile, $"{outputArchivepath}{Path.GetFileNameWithoutExtension(Wpfile)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(Wpfile));
                WriteLog(logFilename, Wpfile + "moved to outputarchievepath");
                Console.WriteLine(Wpfile + "moved to outputarchievepath");
            }

            foreach (var vendorfile in vendorfiles)
            {
                File.Move(vendorfile, $"{outputArchivepath}{Path.GetFileNameWithoutExtension(vendorfile)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(vendorfile));
                WriteLog(logFilename, vendorfile + "moved to outputarchievepath");
                Console.WriteLine(vendorfile + "moved to outputarchievepath");
            }
            foreach (var inputfile in inputfiles)
            {
                File.Move(inputfile, $"{inputArchivepath}{Path.GetFileNameWithoutExtension(inputfile)}" + DateTime.Now.ToString("hhmmss") + Path.GetExtension(inputfile));
                WriteLog(logFilename, inputfile + "moved to inputarchievepath");
                Console.WriteLine(inputfile + "moved to inputarchievepath");
            }

        }

        /// <summary>
        /// write the logs.
        /// </summary>
        /// <param name="logFilename">Name of the logfile.</param>
        public static void WriteLog(String logFilename, string text)
        {
            try
            {
                if (!File.Exists(logFilename))
                {
                    File.Create(logFilename).Close();
                }
                using (StreamWriter logwrite = new StreamWriter(logFilename, true))
                {
                    logwrite.WriteLine(string.Format(text));
                    logwrite.Close();
                }
            }
            catch (Exception ex)
            {
                WriteLog(logFilename, ex.Message);
            }
        }
    }
}
